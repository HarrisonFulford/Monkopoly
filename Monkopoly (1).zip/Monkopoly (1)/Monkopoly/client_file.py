from Labels import *
from theobjects import *
import random
#from boardplaces import *
whichmonkey = input('which monkey do you want to be?, blue, green, red, or pink?')
if whichmonkey == 'blue':
    monkeynumber = 0
if whichmonkey == 'green':
    monkeynumber = 1
if whichmonkey == 'red':
    monkeynumber = 2
if whichmonkey == 'pink':
    monkeynumber = 3
#else: monkeynumber = 0
#input for which monkey they are

class piecelabel:
    def __init__(self, label, money_label, vert_colour, hor_colour):
        self.label = label
        self.money_label = money_label
        self.vert_colour = vert_colour
        self.hor_colour = hor_colour

pieces_list_labels = [piecelabel(monbluelabel, bmoneyvallb, vertbluelinelist, horbluelinelist),
               piecelabel(mongreenlabel, gmoneyvallb, vertgreenlinelist, horgreenlinelist),
               piecelabel(monredlabel, rmoneyvallb, vertredlinelist, horredlinelist),
               piecelabel(monpinklabel, pmoneyvallb, vertpinklinelist, horpinklinelist)]
#gui list and objects of all labels in tkinter

class boardlabel:
    def __init__(self, number, label, smallerlabel, cordx, cordy, colourset, numberinset, managebuty):
        self.number = number
        self.label = label
        self.smallerlabel = smallerlabel
        self.cordx = cordx
        self.cordy = cordy
        self.colourset = colourset
        self.numberinset = numberinset
        self.managebuty = managebuty

board_list_labels = [boardlabel(0, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(1, caledonimg, caledonsmalllb, 0, 0, 0, 1, 260),
                     boardlabel(2, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(3, miltonimg, miltonsmalllb, 0, 43, 0, 2, 260),
                     boardlabel(4, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(5, waynebusimg,'no', 465, 296, 8, 1, 556),
                     boardlabel(6, angolaimg, angolasmalllb, 155, 0, 1, 1, 260),
                     boardlabel(7, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(8, somaliaimg, somaliasmalllb, 155, 43, 1, 2, 260),
                     boardlabel(9, chadimg, chadsmalllb, 155, 86, 1, 3, 260),
                     boardlabel(10, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(11, scarboroughimg, scarboroughsmalllb, 310, 0, 2, 1, 260),
                     boardlabel(12, pepsicompanyimg, 'no', 620, 296, 9, 1, 556),
                     boardlabel(13, markhamimg, markhamsmalllb, 310, 43, 2, 2, 260),
                     boardlabel(14, primarycampusimg, primarycampussmalllb, 310, 86, 2, 3, 260),
                     boardlabel(15, jeffbusimg, 'no', 465, 339, 8, 2, 556),
                     boardlabel(16, gcpimg, gcpsmalllb, 465, 0, 3, 1, 260),
                     boardlabel(17, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(18, mentorlobbyimg, mentorlobbysmalllb, 465, 43, 3, 2, 260),
                     boardlabel(19, bhavbarnimg, bhavbarnsmalllb, 465, 86, 3, 3, 260),
                     boardlabel(20, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(21, mentorgymimg, mentorgymsmalllb, 620, 0, 4, 1, 260),
                     boardlabel(22, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(23, northkoreaimg, northkoreasmalllb, 620, 43, 4, 2, 260),
                     boardlabel(24, mentorofficeimg, mentorofficesmalllb, 620, 86, 4, 3, 260),
                     boardlabel(25, smithbusimg, 'no', 465, 382, 8, 3, 556),
                     boardlabel(26, yehiapyramidimg, yehiapyramidsmalllb, 0, 296, 5, 1, 556),
                     boardlabel(27, egyptimg, egyptsmalllb, 0, 339, 5, 2, 556),
                     boardlabel(28, cokecompanyimg, 'no', 620, 339, 9, 2, 556),
                     boardlabel(29, landdownunderimg, landdownundersmalllb, 0, 382, 5, 3, 556),
                     boardlabel(30, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(31, evancampimg, evancampsmalllb, 155, 296, 6, 1, 556),
                     boardlabel(32, greenwoodimg, greenwoodsmalllb, 155, 339, 6, 2, 556),
                     boardlabel(33, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(34, oakvilleimg, oakvillesmalllb, 155, 382, 6, 3, 556),
                     boardlabel(35, danbusimg, 'no', 465, 382, 8, 4, 556),
                     boardlabel(36, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(37, crystalcoveimg, crystalcovesmalllb, 310, 296, 7, 1, 556),
                     boardlabel(38, 'no', 'no', 'no', 'no', 'no', 'no', 'no'),
                     boardlabel(39, jungleofmonkeysimg, jungleofmonkeyssmalllb, 310, 339, 7, 2, 556)]
#gui list and object for all place labels and houses

class dice:
    def __init__(self, dicenum, dicelb, dicelb2):
        self.dicenum = dicenum
        self.dicelb = dicelb
        self.dicelb2 = dicelb2

dice_list = [dice(1, dice1lb, dice1lb2),
            dice(2, dice2lb, dice2lb2),
            dice(3, dice3lb, dice3lb2),
            dice(4, dice4lb, dice4lb2),
            dice(5, dice5lb, dice5lb2),
            dice(6, dice6lb, dice6lb2)]
#gui list and objects for all the dice and their labels

active_dice_list = [dice1lb, dice1lb2]
#list of the dice that are on the board

class Client:
    #class of the client
    def __init__(self, pieces_list_labels=[], board_list_labels=[], dice_list = [], active_dice_list = [], gameboard=None, monkeynum=None, doubleslabel=None): #host, port
        #self.host = host
        #self.port = port
        #self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.pieces_list_labels = pieces_list_labels
        self.board_list_labels = board_list_labels
        self.dice_list = dice_list
        self.active_dice_list = active_dice_list
        self.gameboard = gameboard
        self.monkeynum = monkeynum
        self.doubleslabel = doubleslabel
        #objects of client
    def move(self, num):
        self.pieces_list_labels[num].label.place(x=self.pieces_list_labels[num].place_x, y=self.pieces_list_labels[num].place_y)
        #move function to move that clients gui piece label
    def guitradefunc(self):
        #trade function
        if self.gameboard.guitrade == True:
            guicounter = 0
            self.gameboard.guitrade = False
            print('gui trade')
            for line in allactivelineslist:
                line.destroy()
            #checks if their is a trade and it is to them

            for item in client.gameboard.board_places_list:
                if item.propertytype == 'property':
                    guicounter += 1
                    if guicounter == 3:
                        break
                    if item.number > 10 and item.number < 20:
                        for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour:
                            line.place(x=client.gameboard.board_places_list[item.number].cordx+110, y=client.gameboard.board_places_list[item.number].cordy-16)
                            universallinelist.append(line)
                            client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour.remove(line)
                            break

                    elif item.number > 30:
                        for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour:
                            line.place(x=client.gameboard.board_places_list[item.number].cordx-94, y=client.gameboard.board_places_list[item.number].cordy-16)
                            client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour.remove(line)
                            break

                    elif item.number > 20 and item.number < 30:
                        for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour:
                            line.place(x=client.gameboard.board_places_list[item.number].cordx-16, y=client.gameboard.board_places_list[item.number].cordy+106)
                            client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour.remove(line)
                            break

                    elif item.number > 0 and item.number < 10:
                        print(item.number, client.gameboard.board_places_list[item.number].owner)
                        for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour:
                            line.place(x=client.gameboard.board_places_list[item.number].cordx-16, y=client.gameboard.board_places_list[item.number].cordy-106)
                            client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour.remove(line)
                            print(client.gameboard.board_places_list[item.number].owner, 'placed')
                            break
                    #sets the piece labels for the trade




    def tradecheck(self):
        #checks if there was a trade
        if self.gameboard.gametrade == True:
            if self.gameboard.gametradeto == client.monkeynum:
                #if it is to them
                totaltradelist = client.gameboard.gametradewhat.split('                    ')
                tradefrom = list(totaltradelist[0])
                tradeto = list(totaltradelist[1])
                for fitem in tradefrom:
                    if fitem == ' ' or fitem == ',' or fitem == '[' or fitem == ']':
                        tradefrom.remove(fitem)
                for fitem in tradefrom:
                    if fitem == ' ' or fitem == '[':
                        tradefrom.remove(fitem)
                for titem in tradeto:
                    if titem == ' ' or titem == ',' or titem == '[' or titem == ']':
                        tradeto.remove(titem)
                for titem in tradeto:
                    if titem == ' ':
                        tradeto.remove(titem)
                print(tradefrom)
                print(tradeto)
                #gets the values of the trade what is being offered
                fcounter = -1
                for fitemf in tradefrom:
                    fcounter += 1
                    tradefrom[fcounter] = int(tradefrom[fcounter])
                tcounter = -1
                for titemt in tradeto:
                    tcounter += 1
                    tradeto[tcounter] = int(tradeto[tcounter])
                #makes all list of values to integer instead of string

                managegui.deiconify()
                #opens the manage gui
                tfcolist = [0, 0]
                ttcolist = [620, 0]
                tfcounter = 0
                ttcounter = 0
                #makes list of values for coordinate placing
                for tf in tradefrom:
                    tfcounter += 1
                    #place the labels on left side for offer
                    client.board_list_labels[tf].smallerlabel.place(x=tfcolist[0], y=tfcolist[1])
                    tfcolist[0] += 155
                    if tfcounter == 4 or tfcounter == 7 or tfcounter == 10:
                        tfcolist[1] += 210
                        tfcolist[0] = 0

                for tt in tradeto:
                    ttcounter += 1
                    client.board_list_labels[tt].smallerlabel.place(x=ttcolist[0], y=ttcolist[1])
                    ttcolist[0] += 155
                    if ttcounter == 4 or ttcounter == 7 or ttcounter == 10:
                        ttcolist[1] += 210
                        ttcolist[0] = 620
                        #places right side for receive

                def accepttradefunc():
                    print('i traded')
                    managegui.withdraw()
                    client.gameboard.accepttrade = True
                    #if they accpet the trade sets the accept value to true to send to client in mainloop


                def passtradefunc():
                    managegui.withdraw()
                    #if they pass just closes the gui
                tradeacceptbut = Button(managegui, bg='green', fg='black', height=2, width=3, text='Accept trade', command=accepttradefunc)
                tradeacceptbut.pack(side='right')
                tradedeclinebut = Button(managegui, bg='green', fg='black', height=2, width=3, text='Decline trade', command=passtradefunc)
                tradedeclinebut.pack(side='left')
                plusbutlist.append(tradeacceptbut)
                plusbutlist.append(tradedeclinebut)
                #makes buttons for accepts and decline

    def housesfunc(self):
        #houses check
        for place in client.gameboard.board_places_list:
            if place.housenumber != 0:
                if place.housenumber != 5:
                    #checks the places houses umber between 1 and 4 to place houses
                    if place.number > 0 and place.number < 10:
                        treecoordlist = [place.cordx + 93, place.cordy - 80]
                        for house in range(0, place.housenumber):
                            for tree90lb in tree90list:
                                tree90lb.place(x=treecoordlist[0], y=treecoordlist[1])
                                treecoordlist[0] += 14
                                tree90list.remove(tree90lb)
                                break
                                #if the place is 0 to 10 place one of the trees in the tree list
                    if place.number > 10 and place.number < 20:
                        treecoordlist = [place.cordx + 93, place.cordy - 80]
                        for house in range(0, place.housenumber):
                            for tree90lb in tree90list:
                                tree90lb.place(x=treecoordlist[0], y=treecoordlist[1])
                                treecoordlist[0] += 14
                                tree90list.remove(tree90lb)
                                break


                else:
                    if place.number > 0 and place.number < 10:
                            for hotel in hotel90list:
                                hotel.place(x=place.cordx + 93, y = place.cordy - 80)
                                hotel90list.remove(hotel)
                                break
                            #if it is equal to 5 means it is a hotel and places a hotel


    def configmoney(self, which):
        client.pieces_list_labels[which].money_label.config(text=client.gameboard.pieces_list[which].money)
        #change the money label functions changes the money label of piece to reflect new money value
    def dicefunc(self):
        #dice function
        if client.gameboard.pieces_list[client.monkeynum].jailcount != 0:
            client.doubleslabel.config(text='JAIL!')
            client.doubleslabel.place(x=444, y =132)
            #places them in jail if they are in jail
        if client.gameboard.dice1 == client.gameboard.dice2:
            client.doubleslabel.config(text='DOUBLES!')
            client.doubleslabel.place(x=444, y =132)
            #if doubles makes doubles
        elif client.gameboard.dice1 != client.gameboard.dice2 and client.gameboard.pieces_list[client.monkeynum].jailcount == 0:
            client.doubleslabel.config(text='')
            #if not doubles or jail label is nothing

        for dice in client.active_dice_list:
            dice.place_forget()
            #forget each dice
        client.active_dice_list.clear()
        for newdice in client.dice_list:
            if newdice.dicenum == client.gameboard.dice1:
                newdice.dicelb.place(x=340, y=560)
                client.active_dice_list.append(newdice.dicelb)
            if newdice.dicenum == client.gameboard.dice2:
                newdice.dicelb2.place(x=380, y=560)
                active_dice_list.append(newdice.dicelb2)
                #place the new dice on the board

    def checkfunc(self):
        #check function to check all other values on changes based from a roll
        clientcounter = -1
        for x in client.gameboard.pieces_list:
            clientcounter += 1
            client.pieces_list_labels[clientcounter].label.place(x=x.place_x, y=x.place_y)
            #for each piece place their label

            itemcounter = -1
            for item in client.gameboard.board_places_list:
                itemcounter += 1
                #for each place
                if item.number == x.board_number:
                    if item.propertytype == 'property':
                        #if the piece is on that place and that place is a property
                        def passfunc():
                            propgui.destroy()
                            #if they pass on the purchased destroy the window for property purchase
                        def buyfunc():
                            #if they buy it
                            if savedpropnum == 12 or savedpropnum == 28:
                                client.gameboard.purchasedcomp = True
                                client.gameboard.whichproperty = savedpropnum
                                propgui.destroy()
                                #if it is a company they are buying close the gui and set the change in the mainloop
                            if savedpropnum == 5 or savedpropnum == 15 or savedpropnum == 25 or savedpropnum == 35:
                                client.gameboard.purchasedbus = True
                                client.gameboard.whichproperty = savedpropnum
                                propgui.destroy()
                                #if it is a bus they are purchasing destroy gui and set the mainloop bus purchase to true
                            else:
                                client.gameboard.purchasedprop = True
                                client.gameboard.whichproperty = savedpropnum
                                propgui.destroy()
                                #if it is a property they purchased set the purchased property to true and destroy the gui

                            if savedpropnum > 10 and savedpropnum < 20:
                                for line in client.pieces_list_labels[savedpiecenum].vert_colour:
                                    line.place(x=client.gameboard.board_places_list[savedpropnum].cordx+110, y=client.gameboard.board_places_list[savedpropnum].cordy-16)
                                    client.pieces_list_labels[savedpiecenum].vert_colour.remove(line)
                                    break

                            elif savedpropnum > 30:
                                for line in client.pieces_list_labels[savedpiecenum].vert_colour:
                                    line.place(x=client.gameboard.board_places_list[savedpropnum].cordx-94, y=client.gameboard.board_places_list[savedpropnum].cordy-16)
                                    client.pieces_list_labels[savedpiecenum].vert_colour.remove(line)
                                    break

                            elif savedpropnum > 20 and savedpropnum < 30:
                                for line in client.pieces_list_labels[savedpiecenum].hor_colour:
                                    line.place(x=client.gameboard.board_places_list[savedpropnum].cordx-16, y=client.gameboard.board_places_list[savedpropnum].cordy+106)
                                    client.pieces_list_labels[savedpiecenum].hor_colour.remove(line)
                                    break

                            elif savedpropnum > 0 and savedpropnum < 10:
                                for line in client.pieces_list_labels[savedpiecenum].hor_colour:
                                    line.place(x=client.gameboard.board_places_list[savedpropnum].cordx-16, y=client.gameboard.board_places_list[savedpropnum].cordy-106)
                                    client.pieces_list_labels[savedpiecenum].hor_colour.remove(line)
                                    allactivelineslist.append(line)
                                    break
                                #All of these check where the property is and place a line under it to indiate the owner of the property based on that

                        if item.owner == 'no':
                            #if the owner of the property is no
                            if client.gameboard.dice1 != client.gameboard.dice2 and x.piece_number == client.monkeynum and gameboard.lastturn == client.monkeynum or client.gameboard.dice1 == client.gameboard.dice2 and x.piece_number == client.monkeynum and gameboard.turn == client.monkeynum:
                                savedpropnum = item.number
                                savedpiecenum = x.piece_number
                                propgui = tk.Toplevel()
                                propgui.geometry('800x608')
                                costlb = Label(propgui, text='$'+str(item.cost), height =1, width=10, font=('Cooper Std Black', 48))
                                costlb.place(x=508, y =1)
                                newlb = tk.Label(propgui, image=client.board_list_labels[itemcounter].label)
                                newlb.place(x=1, y=1)
                                buybutton = Button(propgui, text='buy', bg='green', highlightbackground='green',height=10, width=26, command=buyfunc)
                                buybutton.place(x=528, y=74)
                                passbutton = Button(propgui, text='pass', bg='red', highlightbackground='red',height=10, width=26, command=passfunc)
                                passbutton.place(x=528, y=304)
                                #propgui.wait_window(propgui)
                                #it makes all gui and and buttons that ask for purchased

                        elif item.owner != 'no':
                            if item.number > 10 and item.number < 20:
                                for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour:
                                    line.place(x=client.gameboard.board_places_list[item.number].cordx+110, y=client.gameboard.board_places_list[item.number].cordy-16)
                                    universallinelist.append(line)
                                    client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour.remove(line)
                                    break

                            elif item.number > 30:
                                for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour:
                                    line.place(x=client.gameboard.board_places_list[item.number].cordx-94, y=client.gameboard.board_places_list[item.number].cordy-16)
                                    client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].vert_colour.remove(line)
                                    break

                            elif item.number > 20 and item.number < 30:
                                for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour:
                                    line.place(x=client.gameboard.board_places_list[item.number].cordx-16, y=client.gameboard.board_places_list[item.number].cordy+106)
                                    client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour.remove(line)
                                    break

                            elif item.number > 0 and item.number < 10:
                                for line in client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour:
                                    line.place(x=client.gameboard.board_places_list[item.number].cordx-16, y=client.gameboard.board_places_list[item.number].cordy-106)
                                    client.pieces_list_labels[client.gameboard.board_places_list[item.number].owner].hor_colour.remove(line)
                                    #print(client.gameboard.board_places_list[item.number].owner, 'placed')
                                    allactivelineslist.append(line)
                                    break
                                #if it is not owner it places all the labels for the other client

                    if item.propertytype == 'chest':
                        #if they are on a chest
                        if client.gameboard.dice1 != client.gameboard.dice2 and x.piece_number == client.monkeynum and gameboard.lastturn == client.monkeynum or client.gameboard.dice1 == client.gameboard.dice2 and x.piece_number == client.monkeynum and gameboard.turn == client.monkeynum:
                            if client.gameboard.alreadychance == False:
                                client.gameboard.alreadychance = True
                                m = random.randint(0,12)
                                #makes the random integer for which chance card and checks if it is not creating twice
                                def chestcardfunc():
                                    chestbutton.destroy()
                                    client.gameboard.chance = True
                                    client.gameboard.whichchance = m
                                    client.pieces_list_labels[clientcounter].label.place(x=x.place_x, y=x.place_y)
                                    #send the person and the card function to mainloop to send to server

                                if item.number == 2 or item.number == 17 or item.number == 33:
                                    chestbutton = Button(gui, bg = 'brown', highlightbackground='brown', text=chestlist[m].lbtext, height=12, width=30, command=chestcardfunc)
                                    chestbutton.place(x=300, y=270)
                                    #if it is a baboon bin the colour is brown of the button

                                if item.number == 7 or item.number == 22 or item.number == 36:
                                    chestbutton = Button(gui, bg = 'yellow', highlightbackground='yellow', text=chestlist[m].lbtext, height=12, width=30, command=chestcardfunc)
                                    chestbutton.place(x=300, y=270)
                                    #if it is hazard colour is yellow
                            else:
                                client.gameboard.alreadychance = False
                                #if not set already chance to false
            client.configmoney(x.piece_number)
            #run the configure money function
            #client.pieces_list_labels[clientcounter].money = x.money
            #---------note add a break to the end of boardlist loop, each piece can only be on one board place, so end so it does not take as long
def managefunc():
    #if they hit the manage function
    print('manage')
    #propimagelist = [set0:=[], set1:=[], set2:=[], set3:=[], set4:=[], set5:=[], set6:=[], set7:=[], set8:=[], set9:=[]]
    propimagelist = []
    buttonpluslist = []
    buttonminlst = []
    coordsycounter = 0
    managegui.deiconify()
    #opens manage gui
    for item in client.gameboard.board_places_list:
        if item.owner == client.monkeynum:
            propimagelist.append(item.number)
            #for all properties they own add that to the list

    def managesetfunc(num):
        #if they hit manage on a property set
        class empty:
            def __init__(self, number, housenumber, label):
                self.number = number
                self.housenumber = housenumber
                self.label = label
        emptylist = []
        #make a list of objects of those property

        for but in managebutlist:
            but.destroy()
            #for each in the manage button list it destroys the buttons

        newproplistman = []
        for im in propimagelist:
            if client.gameboard.board_places_list[im].colourset == num:
                newproplistman.append(im)
                #add the list of the new properties for all the properties they own in that colour set

        def confirmfunc():
            #if they confirm on their houses
            managegui.withdraw()
            #closes the manage gui
            if len(emptylist) == 2:
                string = str(emptylist[0].number) + ' ' + str(emptylist[0].housenumber) + '  ' + str(emptylist[1].number) + '  ' + str(emptylist[1].housenumber)
                if emptylist[0].housenumber != 0 or emptylist[1].housenumber != 0:
                    client.gameboard.board_places_list[emptylist[0].number].house0 = True
                    client.gameboard.board_places_list[emptylist[1].number].house0 = True
                    #for properties of two sets mainloop values and sends to server
                else:
                    client.gameboard.board_places_list[emptylist[0].number].house0 = False
                    client.gameboard.board_places_list[emptylist[1].number].house0 = False
                    #else if they are not equal to zero set false and house
            if len(emptylist) == 3:
                string = str(emptylist[0].number) + ' ' + str(emptylist[0].housenumber) + '  ' + str(emptylist[1].number) + '  ' + str(emptylist[1].housenumber) + '   ' + str(emptylist[2].number) + '    ' + str(emptylist[2].housenumber)
                if emptylist[0].housenumber != 0 or emptylist[1].housenumber != 0 or emptylist[2].housenumber != 0:
                    client.gameboard.board_places_list[emptylist[0].number].house0 = True
                    client.gameboard.board_places_list[emptylist[1].number].house0 = True
                    client.gameboard.board_places_list[emptylist[2].number].house0 = True
                    #if three sets mainloop values and sends to server
                else:
                    client.gameboard.board_places_list[emptylist[0].number].house0 = False
                    client.gameboard.board_places_list[emptylist[1].number].house0 = False
                    client.gameboard.board_places_list[emptylist[2].number].house0 = False
                    #for others set false
            client.gameboard.whichhouses = string
            client.gameboard.sendhouses = True
            #set value to string and sendhouses to true in order to send to server
            print(client.gameboard.board_places_list[emptylist[0].number].house0)
            emptylist.clear()
            #clear the empty list

        def plusfunc(propnum):
            #plus functiin
            if client.gameboard.board_places_list[emptylist[propnum].number].completeset == False:
                print('Cannot add houses, this collection is not complete')
                emptylist[0].label.config(text='Set Incomplete')
                #if they dont have complete set does not work
            else:
                if len(emptylist) == 2:
                    if emptylist[0].housenumber != 5 or emptylist[1].housenumber != 5:
                        if propnum == 0:
                            if emptylist[0].housenumber == emptylist[1].housenumber or emptylist[0].housenumber == emptylist[1].housenumber - 1:
                                emptylist[0].housenumber += 1
                                confirmbutton['state'] = NORMAL
                                #if they do and have two and they have the right amount on the other it adds 1 house to that property

                        if propnum == 1:
                            if emptylist[1].housenumber == emptylist[0].housenumber or emptylist[1].housenumber == emptylist[0].housenumber - 1:
                                emptylist[1].housenumber += 1
                                confirmbutton['state'] = NORMAL
                                #if it is the other property same thing check the other one and add a house
                if len(emptylist) == 3:
                    #for three houses same thing
                    if emptylist[0].housenumber != 5 or emptylist[1].housenumber != 5 or emptylist[2].housenumber != 5:
                        if propnum == 0:
                            if emptylist[0].housenumber == emptylist[1].housenumber and emptylist[0].housenumber == emptylist[2].housenumber or emptylist[0].housenumber == emptylist[1].housenumber and emptylist[0].housenumber == emptylist[2].housenumber - 1 or emptylist[0].housenumber == emptylist[2].housenumber and emptylist[0].housenumber == emptylist[1].housenumber - 1 or emptylist[0].housenumber == emptylist[1].housenumber - 1 and emptylist[0].housenumber == emptylist[2].housenumber - 1:
                                emptylist[0].housenumber += 1
                                confirmbutton['state'] = NORMAL
                                #check if the houses values are correct to add
                        if propnum == 1:
                            if emptylist[1].housenumber == emptylist[0].housenumber and emptylist[1].housenumber == emptylist[2].housenumber or emptylist[1].housenumber == emptylist[0].housenumber and emptylist[1].housenumber == emptylist[2].housenumber - 1 or emptylist[1].housenumber == emptylist[2].housenumber and emptylist[1].housenumber == emptylist[0].housenumber - 1 or emptylist[1].housenumber == emptylist[0].housenumber - 1 and emptylist[1].housenumber == emptylist[2].housenumber - 1:
                                emptylist[1].housenumber += 1
                                confirmbutton['state'] = NORMAL
                                #check if the houses values are correct to add
                        if propnum == 2:
                            if emptylist[2].housenumber == emptylist[1].housenumber and emptylist[2].housenumber == emptylist[0].housenumber or emptylist[2].housenumber == emptylist[1].housenumber and emptylist[2].housenumber == emptylist[0].housenumber - 1 or emptylist[2].housenumber == emptylist[0].housenumber and emptylist[2].housenumber == emptylist[1].housenumber - 1 or emptylist[2].housenumber == emptylist[0].housenumber - 1 and emptylist[2].housenumber == emptylist[1].housenumber - 1:
                                emptylist[2].housenumber += 1
                                confirmbutton['state'] = NORMAL
                                #check if the houses values are correct to add
                    emptylist[2].label.config(text='houses :' + str(emptylist[2].housenumber))
                emptylist[0].label.config(text='houses :' + str(emptylist[0].housenumber))
                emptylist[1].label.config(text='houses :' + str(emptylist[1].housenumber))
                #after all change the list of objects to rfeflect houses and strings and new houses added
                #print(emptylist[0].housenumber, emptylist[1].housenumber)

        def minfunc(propnum):
            #minus a house
            if client.gameboard.board_places_list[emptylist[propnum].number].completeset == False:
                print('Cannot add houses, this collection is not complete')
            else:
                if len(emptylist) == 2:
                    if emptylist[0].housenumber != 0 or emptylist[1].housenumber != 0:
                        if propnum == 0:
                            if emptylist[0].housenumber == emptylist[1].housenumber or emptylist[0].housenumber == emptylist[1].housenumber + 1:
                                emptylist[0].housenumber -= 1
                        if propnum == 1:
                            if emptylist[1].housenumber == emptylist[0].housenumber or emptylist[1].housenumber == emptylist[0].housenumber + 1:
                                emptylist[1].housenumber -= 1
                    if emptylist[0].housenumber == 0 and emptylist[1].housenumber == 0 and client.gameboard.board_places_list[emptylist[0].number].house0 == False:
                        print(client.gameboard.board_places_list[emptylist[0].number].house0, 'actual')
                        confirmbutton['state'] = DISABLED
                    else:
                        print('it was not')
                        #same thing check the other values and minus a house if possible and if the houses and now zero disable the send button as to not send a house with zero

                if len(emptylist) == 3:
                    #for three houses
                    if emptylist[0].housenumber != 0 or emptylist[1].housenumber != 0 or emptylist[2].housenumber != 0:
                        if propnum == 0:
                            if emptylist[0].housenumber == emptylist[1].housenumber and emptylist[0].housenumber == emptylist[2].housenumber or emptylist[0].housenumber == emptylist[1].housenumber and emptylist[0].housenumber == emptylist[2].housenumber + 1 or emptylist[0].housenumber == emptylist[2].housenumber and emptylist[0].housenumber == emptylist[1].housenumber + 1 or emptylist[0].housenumber == emptylist[1].housenumber + 1 and emptylist[0].housenumber == emptylist[2].housenumber + 1:
                                emptylist[0].housenumber -= 1
                        if propnum == 1:
                            if emptylist[1].housenumber == emptylist[0].housenumber and emptylist[1].housenumber == emptylist[2].housenumber or emptylist[1].housenumber == emptylist[0].housenumber and emptylist[1].housenumber == emptylist[2].housenumber + 1 or emptylist[1].housenumber == emptylist[2].housenumber and emptylist[1].housenumber == emptylist[0].housenumber + 1 or emptylist[1].housenumber == emptylist[0].housenumber + 1 and emptylist[1].housenumber == emptylist[2].housenumber + 1:
                                emptylist[1].housenumber -= 1
                        if propnum == 2:
                            if emptylist[2].housenumber == emptylist[1].housenumber and emptylist[2].housenumber == emptylist[0].housenumber or emptylist[2].housenumber == emptylist[1].housenumber and emptylist[2].housenumber == emptylist[0].housenumber + 1 or emptylist[2].housenumber == emptylist[0].housenumber and emptylist[2].housenumber == emptylist[1].housenumber + 1 or emptylist[2].housenumber == emptylist[0].housenumber + 1 and emptylist[2].housenumber == emptylist[1].housenumber + 1:
                                emptylist[2].housenumber -= 1
                    if emptylist[0].housenumber == 0 and emptylist[1].housenumber == 0 and emptylist[2].housenumber == 0:
                        confirmbutton['state'] = DISABLED
                    emptylist[2].label.config(text='houses :' + str(emptylist[2].housenumber))
                emptylist[0].label.config(text='houses :' + str(emptylist[0].housenumber))
                emptylist[1].label.config(text='houses :' + str(emptylist[1].housenumber))
                #check the other house values and if possible minus a house and update list of values

        def mortfunc(propnum):
            #mortgage sends to server that it is mortgaged
            managegui.withdraw()
            print(propnum, 'this is one client mort')
            client.gameboard.mortgagewhich = propnum
            client.gameboard.mortgage = True



        confirmbutton = Button(managegui, bg='green', highlightbackground='green', fg='black', height=2, width=3, text='confirm', command=confirmfunc)
        confirmbutton.pack(side='right')
        confirmbutton['state'] = DISABLED
        plusbutlist.append(confirmbutton)
        #makes the confirm button for confirm they are buying houses

        coordlist = [0, 0]
        propcounter = -1
        for im in newproplistman:
            propcounter += 1
            if client.board_list_labels[im].colourset == num:
                client.board_list_labels[im].smallerlabel.place(x=coordlist[0], y=coordlist[1])
                coordlist[0] += 155
                houselb = Label(managegui, text='houses: '+str(0))
                houselb.place(x=coordlist[0]-115, y=coordlist[1]+200)
                newempty = empty(im, 0, houselb)
                #for each house in correct colour set place
                #add it to the emptylist and make the object for that emptylist

                emptylist.append(newempty)
                plusbutton = Button(managegui, height=1, width=1, text='+1', command=lambda propnum=propcounter: plusfunc(propnum))
                plusbutton.place(x=coordlist[0]-85, y=coordlist[1]+175)
                plusbutlist.append(plusbutton)
                minbutton = Button(managegui, height=1, width=1, text='-1', command=lambda propnum=propcounter: minfunc(propnum))
                minbutton.place(x=coordlist[0]-125, y=coordlist[1]+175)
                plusbutlist.append(minbutton)
                if client.gameboard.board_places_list[im].mortgaged == False:
                    text = 'mortgage'
                #make buttons for mortgage and minus and plus
                else:
                    text = 'unmortgage'
                mortbutton = Button(managegui, height=1, width=3, text=text, command=lambda propnum=im: mortfunc(propnum))
                mortbutton.place(x=coordlist[0]-125, y=coordlist[1]+225)
                plusbutlist.append(mortbutton)
                #add plus button list of buttons to check for destorying

            else:
                client.board_list_labels[im].smallerlabel.place(x=-1000, y=-1000)
                #place the labels


    managebutlist = []
    proplistcounter = -1
    for im in propimagelist:
        proplistcounter += 1
        client.board_list_labels[im].smallerlabel.place(x=client.board_list_labels[im].cordx, y=client.board_list_labels[im].cordy)
        if client.board_list_labels[im].numberinset == 1 or client.board_list_labels[im].numberinset == 2 and proplistcounter != 0 and im - 1 != propimagelist[proplistcounter-1] or client.board_list_labels[im].numberinset == 2 and proplistcounter == 0 or client.board_list_labels[im].numberinset == 2 and proplistcounter != 0 and im - 2 != propimagelist[proplistcounter-1] or client.board_list_labels[im].numberinset == 3 and proplistcounter == 0 or client.board_list_labels[im].numberinset == 3 and proplistcounter != 0 and im - 1 != propimagelist[proplistcounter-1] or client.board_list_labels[im].numberinset == 3 and proplistcounter != 0 and im - 2 != propimagelist[proplistcounter-1]:
            managesetbut = Button(managegui, height=1, width=6, text='manage set', command=lambda num=client.board_list_labels[im].colourset: managesetfunc(num))
            managebutlist.append(managesetbut)
            print('manage create')
            managesetbut.place(x=client.board_list_labels[im].cordx + 33, y=client.board_list_labels[im].managebuty)
            #for every property that is owned put them together and make a manage button to manage that set

def tradefunc():
    #make the trade function
    def hey(oppmonkey):
        ourfinaladdlist = []
        oppfinaladdlist = []
        #for opposing monkey

        def ouraddfunc(num, add):
            if num in ourfinaladdlist:
                ourfinaladdlist.remove(num)
                addbutlist[add - 1].config(text='add')
            else:
                ourfinaladdlist.append(num)
                addbutlist[add - 1].config(text='remove')
                #adds to trade they have
        def oppaddfunc(num, add):
            if num in oppfinaladdlist:
                oppfinaladdlist.remove(num)
                oppaddbutlist[add - 1].config(text='add')
            else:
                oppfinaladdlist.append(num)
                oppaddbutlist[add - 1].config(text='remove')
                #adds to trade for opposing monkey

        def confirmtradefunc():
            managegui.withdraw()
            client.gameboard.tradefrom = client.monkeynum
            client.gameboard.tradeto = oppmonkey
            client.gameboard.whattrade = str(ourfinaladdlist) + '                    ' + str(oppfinaladdlist)
            client.gameboard.trade = True
            #confirm sends to server in mainloop they got a trade and what it is what is the offer and receive


        confirmbutton = Button(managegui, bg='green', highlightbackground='green', fg='black', height=2, width=5, text='confirm', command=confirmtradefunc)
        confirmbutton.pack(side='right')
        plusbutlist.append(confirmbutton)
        #make the confirm buttonb

        ourmonkeylist = []
        oppmonkeylist = []
        #list for properties given and taken by the current and opposing monkey
        managegui.deiconify()
        #make the manage gui
        for item in client.gameboard.board_places_list:
            if item.owner == client.monkeynum:
                ourmonkeylist.append(item.number)
                #if they own add to their monkey list
            elif item.owner == oppmonkey:
                oppmonkeylist.append(item.number)
                #if one trading with owns add to opposing monkey


        ourcolist = [0, 0]
        oppcolist = [620, 0]
        #list of coordinates for placing gui
        ourcocounter = 0
        oppcocounter = 0
        addbutlist = []
        oppaddbutlist = []
        #list of buttons
        for ourim in ourmonkeylist:
            ourcocounter += 1
            client.board_list_labels[ourim].smallerlabel.place(x=ourcolist[0], y=ourcolist[1])
            ourcolist[0] += 155
            #for all monkeys place the label and change coordinate
            if ourcocounter == 4 or ourcocounter == 7 or ourcocounter == 10:
                ourcolist[1] += 210
                ourcolist[0] = 0
                #if they reach end of row go down instead of continuing linearly

            addbutton = Button(managegui, height=1, width=2, text='add', command=lambda propnum=ourim, butnum=ourcocounter: ouraddfunc(propnum, butnum))
            addbutton.place(x=ourcolist[0]-85, y=ourcolist[1]+175)
            plusbutlist.append(addbutton)
            addbutlist.append(addbutton)
            #add button to add to trade

        for oppim in oppmonkeylist:
            oppcocounter += 1
            client.board_list_labels[oppim].smallerlabel.place(x=oppcolist[0], y=oppcolist[1])
            oppcolist[0] += 155
            #for opposing monkey property place their labels
            if oppcocounter == 4 or oppcocounter == 7 or oppcocounter == 10:
                oppcolist[1] += 210
                oppcolist[0] = 620
                #if they reach end of row shift down

            oppaddbutton = Button(managegui, height=1, width=2, text='add', command=lambda propnum=oppim, butnum=oppcocounter: oppaddfunc(propnum, butnum))
            oppaddbutton.place(x=oppcolist[0]-85, y=oppcolist[1]+175)
            plusbutlist.append(oppaddbutton)
            oppaddbutlist.append(oppaddbutton)
            #opposing monkey add property button

    trademonkeygui = Tk()
    trademonkeygui.title("Trade")
    #make the trade window to initiate who they want to trade with
    trademonkeygui.geometry('600x300')
    tradebluebutton = Button(trademonkeygui, height=5, width=5, text='blue', command=lambda oppmon=0: hey(oppmon))
    tradebluebutton.place(x='100', y='50')
    tradegreenbutton = Button(trademonkeygui, height=5, width=5, text='green', command=lambda oppmon=1: hey(oppmon))
    tradegreenbutton.place(x='200', y='50')
    traderedbutton = Button(trademonkeygui, height=5, width=5, text='red', command=lambda oppmon=2: hey(oppmon))
    traderedbutton.place(x='300', y='50')
    tradepinkbutton = Button(trademonkeygui, height=5, width=5, text='pink', command=lambda oppmon=3: hey(oppmon))
    tradepinkbutton.place(x='400', y='50')
    #all buttons for which monkey they want to trade with
    if client.monkeynum == 0:
        tradebluebutton['state'] = DISABLED
    if client.monkeynum == 1:
        tradegreenbutton['state'] = DISABLED
    if client.monkeynum == 2:
        traderedbutton['state'] = DISABLED
    if client.monkeynum == 3:
        tradepinkbutton['state'] = DISABLED
        #if they are the monkey it disables the button so they dont trade with themselves




client = Client(pieces_list_labels = pieces_list_labels, board_list_labels = board_list_labels, dice_list = dice_list, active_dice_list = active_dice_list, gameboard=gameboard, monkeynum=monkeynumber, doubleslabel=Label(gui, text='DOUBLES!', height =1, width=10, bg='#D5E8D4', fg='green', font=('Cooper Std Black', 30)))
#make the actual client with all of their attributes necessary to the client