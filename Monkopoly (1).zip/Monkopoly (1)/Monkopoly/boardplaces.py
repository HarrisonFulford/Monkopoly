from Labels import *

class boardplaces:
    def __init__(self, number, cordx, cordy, propertyname, propertytype, subpropertytype, label, cost, owner, rent0, rent1, rent2, rent3, rent4, rent5, housenumber, smallerlabel, mortgaged):
        self.number = number
        self.cordx = cordx
        self.cordy = cordy
        self.property = propertyname
        self.propertytype = propertytype
        self.subpropertytype = subpropertytype
        self.label = label
        self.cost = cost
        self.owner = owner
        self.rent0 = rent0
        self.rent1 = rent1
        self.rent2 = rent2
        self.rent3 = rent3
        self.rent4 = rent4
        self.rent5 = rent5
        self.housenumber = housenumber
        self.smallerlabel = smallerlabel
        self.mortgaged = False
#class of board places which number two coordinates, property name, type, and the label image that pops up

boardplaceslist = [boardplaces(0, 640, 715, 'GO', 'go', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(1, 588, 715, 'Caledon', 'property', 'property', caledonimg, 60, 'no', 2, 10, 30, 90, 160, 250, 0, caledonsmalllb, False),
                   boardplaces(2, 532, 715, 'Baboon Bin', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(3, 480, 715, 'Milton','property', 'property', miltonimg, 60, 'no', 4, 20, 60, 180, 320, 450, 0, miltonsmalllb, False),
                   boardplaces(4, 416, 715, 'Mentor School Fees 200', 'tax', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(5, 360, 715, 'Wayne Bus', 'property', 'bus', waynebusimg, 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 'no', False),
                   boardplaces(6, 304, 715, 'Angola', 'property', 'property', angolaimg, 100, 'no', 6, 30, 90, 270, 400, 550, 0, angolasmalllb, False),
                   boardplaces(7, 248, 715, 'Healthcare Hazard', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(8, 192, 715, 'Somalia', 'property', 'property', somaliaimg, 100, 'no', 6, 30, 90, 270, 400, 550, 0, somaliasmalllb, False), #to demonstrate the new debt function changed base rent to 1600
                   boardplaces(9, 136, 715, 'Chad', 'property', 'property', chadimg, 120, 'no', 8, 40, 100, 300, 450, 600, 0, chadsmalllb, False),
                   boardplaces(10, 5, 715, 'Jail', 'jail', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(11, 5, 590, 'Scarborough', 'property', 'property', scarboroughimg, 140, 'no', 10, 50, 150, 450, 625, 750, 0, scarboroughsmalllb, False),
                   boardplaces(12, 5, 534, 'Pepsi Company', 'property', 'company', pepsicompanyimg, 150, 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(13, 5, 478, 'Markham', 'property', 'property', markhamimg, 140, 'no', 10, 50, 150, 450, 625, 750, 0, markhamsmalllb, False),
                   boardplaces(14, 5, 420, 'Primary Campus', 'property', 'property', primarycampusimg, 160, 'no', 12, 60, 180, 500, 700, 900, 0, primarycampussmalllb, False),
                   boardplaces(15, 5, 364, 'Jeff Bus', 'property', 'bus', jeffbusimg, 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 'no', False),
                   boardplaces(16, 5, 302, 'GCP', 'property', 'property', gcpimg, 180, 'no', 14, 70, 200, 550, 750, 950, 0, gcpsmalllb, False),
                   boardplaces(17, 5, 246, 'Baboon Bin', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(18, 5, 188, 'Mentor Lobby', 'property', 'property', mentorlobbyimg, 180, 'no', 14, 70, 200, 550, 750, 950, 0, mentorlobbysmalllb, False),
                   boardplaces(19, 5, 132, 'Bhav Barn', 'property', 'property', bhavbarnimg, 200, 'no', 16, 80, 220, 600, 800, 1000, 0, bhavbarnsmalllb, False),
                   boardplaces(20, 5, 5, 'Lunch Break', 'lunch', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(21, 136, 5, 'Mentor Gym', 'property', 'property', mentorgymimg, 220, 'no', 18, 90, 250, 700, 875, 1050, 0, mentorgymsmalllb, False),
                   boardplaces(22, 192, 5, 'Healthcare hazard', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(23, 248, 5, 'North Korea', 'property', 'property', northkoreaimg, 220, 'no', 18, 90, 250, 700, 875, 1050, 0, northkoreasmalllb, False),
                   boardplaces(24, 304, 5 ,'mentor office', 'property', 'property', mentorofficeimg, 240, 'no', 20, 100, 300, 750, 925, 1100, 0, mentorofficesmalllb, False),
                   boardplaces(25, 360, 5, 'Smith Bus', 'property', 'bus', smithbusimg, 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 'no', False),
                   boardplaces(26, 416, 5, 'Yehia Pyramid', 'property', 'property', yehiapyramidimg, 260, 'no', 22, 110, 330, 800, 975, 1150, 0, yehiapyramidsmalllb, False),
                   boardplaces(27, 472, 5, 'Egypt', 'property', 'property', egyptimg, 260, 'no', 22, 110, 330, 800, 975, 1150, 0, egyptsmalllb, False),
                   boardplaces(28, 532, 5, 'Coca Cola Company', 'property', 'company', cokecompanyimg, 150, 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(29, 588, 5, 'Land Down Under', 'property', 'property', landdownunderimg, 280, 'no', 24, 120, 360, 850, 1025, 1200, 0, landdownundersmalllb, False),
                   boardplaces(30, 710, 5, 'Go To Brampton', 'gotojail', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(31, 710, 132, 'Evan Camp', 'property', 'property', evancampimg, 300, 'no', 26, 130, 390, 900, 1100, 1275, 0, evancampsmalllb, False),
                   boardplaces(32, 710, 188, 'Greenland Park', 'property', 'property', greenwoodimg, 300, 'no', 26, 130, 390, 900, 1100, 1275, 0, greenwoodsmalllb, False),
                   boardplaces(33, 710, 246, 'Baboon Bin', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(34, 710, 302, 'Oakville', 'property', 'property', oakvilleimg, 320, 'no', 28, 150, 450, 1000, 1200, 1400, 0, oakvillesmalllb, False),
                   boardplaces(35, 710, 364, 'Dan Bus', 'property', 'bus', danbusimg, 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 'no', False),
                   boardplaces(36, 710, 422, 'Healthcare hazard', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(37, 710, 478, 'Crystal Cove', 'property', 'property', crystalcoveimg, 350, 'no', 35, 175, 500, 1100, 1300, 1500, 0, crystalcovesmalllb, False),
                   boardplaces(38, 710, 534, 'field trip 100', 'tax', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False),
                   boardplaces(39, 710, 590, 'jungle of the monkeys', 'property', 'property', jungleofmonkeysimg, 400, 'no', 50, 200, 600, 1400, 1700, 2000, 0, jungleofmonkeyssmalllb, False)]
#list of all boardplaces with there numbers coordinates, name, etc.