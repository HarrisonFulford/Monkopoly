from tkinter import *
import tkinter as tk
import ctypes
from PIL import ImageTk, Image
import random
from pieces import pieces
from boardplaces import boardplaces
from chest import chest
from dice import dice

gui = Tk()
gui.geometry("950x750")
gui.title('Monkopoly')
doubleslb = Label(gui, text='DOUBLES!', height =1, width=10, bg='#D5E8D4', font=('Cooper Std Black', 30))

frame = Frame(gui, width=2000, height=2000)
frame.pack()
frame.place(anchor='center', relx=0.5, rely=0.5)
#boardimg0 = ImageTk.PhotoImage(Image.open('monboard14.jpg'))
boardimg = Image.open('monboard16.jpg')
image2 = boardimg.resize((737, 738),Image.BICUBIC)
boardimg2=ImageTk.PhotoImage(image2)
boardlabel = Label(frame, image = boardimg2)
boardlabel.pack()

bluemoney = tk.PhotoImage(file='monkeymoneycokeb.png')
bluemoneylb = tk.Label(gui, image=bluemoney)
bluemoneylb.place(x=1, y=1)
bimg = Image.open('monkeyfaceblue4.png')
bimg2 = bimg.resize((65, 60),Image.BICUBIC)
bimg3=ImageTk.PhotoImage(bimg2)
blabel = Label(gui, image = bimg3)
blabel.place(x=18, y=20)
redmoney = tk.PhotoImage(file='monkeymoneyr4.png')
redmoneylb = tk.Label(gui, image=redmoney)
redmoneylb.place(x=1, y=626)
rimg = Image.open('newmonred.png')
rimg2 = rimg.resize((65, 60),Image.BICUBIC)
rimg3=ImageTk.PhotoImage(rimg2)
rlabel = Label(gui, image = rimg3)
rlabel.place(x=18, y=646)
greenmoney = tk.PhotoImage(file='monkeymoneyg4.png')
greenmoneylb = tk.Label(gui, image=greenmoney)
greenmoneylb.place(x=845, y=1)
gimg = Image.open('newmongreen.png')
gimg2 = gimg.resize((65, 60),Image.BICUBIC)
gimg3=ImageTk.PhotoImage(gimg2)
glabel = Label(gui, image = gimg3)
glabel.place(x=863, y=20)
pinkmoney = tk.PhotoImage(file='monkeymoneyp4.png')
pinkmoneylb = tk.Label(gui, image=pinkmoney)
pinkmoneylb.place(x=845, y=626)
pimg = Image.open('newmonpink.png')
pimg2 = pimg.resize((65, 60),Image.BICUBIC)
pimg3=ImageTk.PhotoImage(pimg2)
plabel = Label(gui, image = pimg3)
plabel.place(x=863, y=646)

monblueimg = tk.PhotoImage(file='monkeyfaceblue4.png')
mongreenimg = tk.PhotoImage(file='newmongreen.png')
monredimg = tk.PhotoImage(file='newmonred.png')
monpinkimg = tk.PhotoImage(file='newmonpink.png')
monbluelabel = tk.Label(frame, image = monblueimg, width=26, height=24)
monbluelabel.place(x = '640', y = '715')
mongreenlabel = Label(frame, image=mongreenimg)
mongreenlabel.place(x = '640', y = '690')
monredlabel = Label(frame, image=monredimg)
monredlabel.place(x = '640', y = '665')
monpinklabel = Label(frame, image=monpinkimg)
monpinklabel.place(x = '640', y = '640')

bmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='blue', fg='white')
bmoneyvallb.place(x=22, y=84)
rmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='red', fg='white')
rmoneyvallb.place(x=22, y=710)
gmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='#28DC28', fg='white')
gmoneyvallb.place(x=868, y=84)
pmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='#C525E2', fg='white')
pmoneyvallb.place(x=868, y=710)

dice1img = tk.PhotoImage(file='dice1.png')
dice1lb = tk.Label(gui, image=dice1img)
dice1lb2 = tk.Label(gui, image=dice1img)
dice2img = tk.PhotoImage(file='dice2.png')
dice2lb = tk.Label(gui, image=dice2img)
dice2lb2 = tk.Label(gui, image=dice2img)
dice3img = tk.PhotoImage(file='dice3.png')
dice3lb = tk.Label(gui, image=dice3img)
dice3lb2 = tk.Label(gui, image=dice3img)
dice4img = tk.PhotoImage(file='dice4.png')
dice4lb = tk.Label(gui, image=dice4img)
dice4lb2 = tk.Label(gui, image=dice4img)
dice5img = tk.PhotoImage(file='dice5.png')
dice5lb = tk.Label(gui, image=dice5img)
dice5lb2 = tk.Label(gui, image=dice5img)
dice6img = tk.PhotoImage(file='dice6.png')
dice6lb = tk.Label(gui, image=dice6img)
dice6lb2 = tk.Label(gui, image=dice6img)

#caledonimg = tk.PhotoImage(file='caledon.png')
#caledonlb = tk.Label(gui, image=caledonimg)
#caledonlb.place(x=1, y=1)

dicelist = [dice(1, dice1lb, dice1lb2),
            dice(2, dice2lb, dice2lb2),
            dice(3, dice3lb, dice3lb2),
            dice(4, dice4lb, dice4lb2),
            dice(5, dice5lb, dice5lb2),
            dice(6, dice6lb, dice6lb2)]
activedicelist = [dice1lb, dice1lb2]

pieceslist = [pieces(1, 'yes', "Blue Monkey", 640, 715, 0, monbluelabel, 1500, bmoneyvallb),
              pieces(2, 'no', "Green Monkey", 640, 690, 0, mongreenlabel, 1500, gmoneyvallb),
              pieces(3, 'no', "Red Monkey", 640, 665, 0, monredlabel, 1500, rmoneyvallb),
              pieces(4, 'no', "Pink Monkey", 640, 640, 0, monpinklabel, 1500, pmoneyvallb)]

boardplaceslist = [boardplaces(0, 640, 715, 'GO', 'go', 'no'),
                   boardplaces(1, 584, 715, 'Caledon', 'property', 'caledonimg3'),
                   boardplaces(2, 528, 715, 'Baboon Bin', 'chest', 'no'),
                   boardplaces(3, 472, 715, 'Milton','property', 'no'),
                   boardplaces(4, 416, 715, 'Mentor School Fees 200', 'tax', 'no'),
                   boardplaces(5, 360, 715, 'Wayne Bus', 'bus', 'no'),
                   boardplaces(6, 304, 715, 'Angola', 'property', 'no'),
                   boardplaces(7, 248, 715, 'Healthcare Hazard', 'chest', 'no'),
                   boardplaces(8, 192, 715, 'Somalia', 'property', 'no'),
                   boardplaces(9, 136, 715, 'Chad', 'property', 'no'),
                   boardplaces(10, 5, 715, 'Jail', 'jail', 'no'),
                   boardplaces(11, 5, 590, 'Scarborough', 'property', 'no'),
                   boardplaces(12, 5, 534, 'Pepsi Company', 'company', 'no'),
                   boardplaces(13, 5, 478, 'Markham', 'property', 'no'),
                   boardplaces(14, 5, 420, 'Primary Campus', 'property', 'no'),
                   boardplaces(15, 5, 364, 'Jeff Bus', 'bus', 'no'),
                   boardplaces(16, 5, 302, 'GCP', 'property', 'no'),
                   boardplaces(17, 5, 246, 'Baboon Bin', 'chest', 'no'),
                   boardplaces(18, 5, 188, 'Mentor Lobby', 'property', 'no'),
                   boardplaces(19, 5, 132, 'Mentor Office', 'property', 'no'),
                   boardplaces(20, 5, 5, 'Lunch Break', 'lunch', 'no'),
                   boardplaces(21, 136, 5, 'Mentor Gym', 'property', 'no'),
                   boardplaces(22, 192, 5, 'Healthcare hazard', 'chest', 'no'),
                   boardplaces(23, 248, 5, 'North Korea', 'property', 'no'),
                   boardplaces(24, 304, 5 ,'Smith Class', 'property', 'no'),
                   boardplaces(25, 360, 5, 'Smith Bus', 'bus', 'no'),
                   boardplaces(26, 416, 5, 'Yehia Pyramid', 'property', 'no'),
                   boardplaces(27, 472, 5, 'Egypt', 'property', 'no'),
                   boardplaces(28, 528, 5, 'Coca Cola Company', 'company', 'no'),
                   boardplaces(29, 584, 5, 'Land Down Under', 'property', 'no'),
                   boardplaces(30, 710, 5, 'Go To Brampton', 'gotojail', 'no'),
                   boardplaces(31, 710, 132, 'Mentor Library', 'property', 'no'),
                   boardplaces(32, 710, 188, 'Greenland Park', 'property', 'no'),
                   boardplaces(33, 710, 246, 'Baboon Bin', 'chest', 'no'),
                   boardplaces(34, 710, 302, 'Oakville', 'property', 'no'),
                   boardplaces(35, 710, 364, 'Dan Bus', 'bus', 'no'),
                   boardplaces(36, 710, 422, 'Healthcare hazard', 'chest', 'no'),
                   boardplaces(37, 710, 478, 'Crystal Cove', 'property', 'no'),
                   boardplaces(38, 710, 534, 'field trip 100', 'tax', 'no'),
                   boardplaces(39, 710, 490, 'Ms. K Class', 'property', 'no')]

chestlist = [chest('You were late coming in from lunch\n go to the office', 24, -0, 'no'),
             chest('Advance to Smith class to get some cokes', 0, -0, 'no'),
             chest('Monkey fees, lose 50 cokes', 'no', -50, 'no'),
             chest('Brayden needs your muck\n lose 25 cokes', 'no', -25, 'no'),
             chest('You hate yourself\n go to Scarborough', 11, -0, 'no'),
             chest('You decided you were tired of cokes\n go to the Pepsi company', 12, -0, 'no'),
             chest('You completed an assignment on time\n receive 50 cokes', 'no', +50, 'no'),
             chest('Bhavjeet wants you to be his Hartag\n he gave you 200 cokes for it', 'no', +200, 'no'),
             chest('Smith deemed you king of the monkets\n Receive 100 cokes', 'no', +100, 'no'),
             chest('Go back three spaces', '-3', -0, 'no'),
             chest('Go back three spaces', '-3', -0, 'no'),
             chest('Take a trip on Bus Wayne', 5, -0, 'no'),
             chest('You a ugly ah monkey and won\n second last in a beauty contest\n collect 10 cokes', 'no', +10, 'no'),
             chest('Some monkey robbed a class\n and dropped the cokes\n collect 150 cokes', 'no', +150, 'no'),
             chest('You brought your coke into class\n and Mcrae took it\n lose 100 cokes', 'no', -100, 'no')]

def newmovefunc():
    dice1 = random.randint(1,6)
    dice2 = random.randint(1,6)
    for item in activedicelist:
        item.place_forget()
    activedicelist.clear()
    for z in dicelist:
        if z.dicenum == dice1:
            z.dicelb.place(x=340, y=560)
            activedicelist.append(z.dicelb)
        if z.dicenum == dice2:
            z.dicelb2.place(x=380, y=560)
            activedicelist.append(z.dicelb2)
    inp = dice1 + dice2
    for x in pieceslist:
        if x.turn == 'yes':
            if dice1 == dice2:
                global doubleslb
                doubleslb = Label(gui, text='DOUBLES!', height =1, width=10, bg='#D5E8D4', fg='green', font=('Cooper Std Black', 30))
                doubleslb.place(x=428, y =132)
            if dice1 != dice2:
                doubleslb.config(text='')
                if x.piecenumber == 4:
                    x.piecenumber = 0
                newx = x.piecenumber - 1
                pieceslist[newx].turn = 'no'
                pieceslist[x.piecenumber].turn = 'yes'

            x.boardnumber += inp
            if x.boardnumber >= 40:
                x.boardnumber -= 40
                x.money += 200
                x.moneylabel.config(text=x.money)

            for item in boardplaceslist:
                if item.number == x.boardnumber:
                    x.placex = item.cordx
                    x.placey = item.cordy
                    for y in pieceslist:
                        if y.boardnumber == x.boardnumber and x.boardnumber != 0 and x.name != y.name:
                            if x.boardnumber <=10:
                                x.placey = y.placey - 30
                            if x.boardnumber >=11 and x.boardnumber <=20:
                                x.placex = y.placex + 30
                            if x.boardnumber >=21 and x.boardnumber <30:
                                x.placey = y.placey + 30
                            if x.boardnumber >=31:
                                x.placex = y.placex - 30
                    x.label.place(x = x.placex, y = x.placey)

                    if item.propertytype == 'chest':
                        m = random.randint(0,14)
                        def chestbuttondestroy():
                            chestbutton.destroy()
                            rollbut['state'] = NORMAL
                            x.money += chestlist[m].moneycom
                            x.moneylabel.config(text=x.money)
                            if chestlist[m].movecom != 'no' and chestlist[m].movecom != '-3':
                                if x.boardnumber < chestlist[m].movecom:
                                    x.money += 200
                                x.boardnumber = chestlist[m].movecom

                            if chestlist[m].movecom == '-3':
                                newxb = int(x.boardnumber) - 3
                                x.boardnumber = newxb
                                if x.boardnumber == 33:
                                    print('33')
                            for item in boardplaceslist:
                                if item.number == x.boardnumber:
                                    x.placex = item.cordx
                                    x.placey = item.cordy
                                    for y in pieceslist:
                                        if y.boardnumber == x.boardnumber and x.boardnumber != 0 and x.name != y.name:
                                            if x.boardnumber <=10:
                                                x.placey = y.placey - 30
                                            if x.boardnumber >=11 and x.boardnumber <=20:
                                                x.placex = y.placex + 30
                                            if x.boardnumber >=21 and x.boardnumber <30:
                                                x.placey = y.placey + 30
                                            if x.boardnumber >=31:
                                                x.placex = y.placex - 30
                                    x.label.place(x = x.placex, y = x.placey)
                        #m = random.randint(0,39)
                        if x.boardnumber == 2 or x.boardnumber == 17 or x.boardnumber == 33:
                            chestbutton = Button(gui, bg = 'brown', highlightbackground='brown', text=chestlist[m].lbtext, height=12, width=30, command=chestbuttondestroy)
                            chestbutton.place(x=225, y=270)
                            rollbut['state'] = DISABLED
                        if x.boardnumber == 7 or x.boardnumber == 22 or x.boardnumber == 36:
                            chestbutton = Button(gui, bg = 'yellow', highlightbackground='yellow', text=chestlist[m].lbtext, height=12, width=30, command=chestbuttondestroy)
                            chestbutton.place(x=225, y=270)
                            rollbut['state'] = DISABLED
                    if item.propertytype == 'property':
                        propgui = Tk()
                        propgui.title(item.property)
                        propgui.geometry('500x400+300+300')
                        caledonimg = Image.open('caledon.png')
                        caledonimg2 = caledonimg.resize((400, 400),Image.BICUBIC)
                        caledonimg3=ImageTk.PhotoImage(caledonimg2)
                        newlabel = Label(propgui, image = caledonimg3)
                        newlabel.place(x=40, y=40)
                        propgui.mainloop()

            break
playerturngui = Tk()
playerturngui.geometry('350x200+300+300')
playerturngui.title('Player Turn')
rollbut = Button(playerturngui, height=5, width=5, text='roll', command=newmovefunc)
rollbut.place(x = '1', y = '1')

#lb.place(x='100', y='1')
def destroyfunc():
    gui.destroy()
    playerturngui.destroy()

gui.resizable(False, False)
playerturngui.resizable(False, False)
def nah():
    pass
playerturngui.wm_protocol("WM_DELETE_WINDOW", nah)
gui.wm_protocol("WM_DELETE_WINDOW", destroyfunc)
playerturngui.mainloop()
gui.mainloop()


