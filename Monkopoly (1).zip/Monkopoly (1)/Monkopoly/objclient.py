import socket
import pickle
import threading
from client_file import *
import time
#import necessary files and objects

def receive_data(client_socket):
    while True:
        #through the socket thread always trying to receive data from server
        data = client_socket.recv(8192)
        if not data:
            break
        #receives it
        newgameboard = pickle.loads(data)
        #loads the data as the newobjects
        #print(f'Turn: {new_obj.turn}')
        client.gameboard.gameover = newgameboard.gameover
        client.gameboard.gametrade = newgameboard.gametrade
        client.gameboard.gametradefrom = newgameboard.gametradefrom
        client.gameboard.gametradeto = newgameboard.gametradeto
        client.gameboard.gametradewhat = newgameboard.gametradewhat
        client.gameboard.guitrade = newgameboard.guitrade
        client.gameboard.turn = newgameboard.turn
        client.gameboard.lastturn = newgameboard.lastturn
        client.gameboard.dice1 = newgameboard.dice1
        client.gameboard.dice2 = newgameboard.dice2
        #sets the clients version of the game board to that of the new received game board
        #rollbut['state'] = DISABLED
        client.gameboard.activebutton = False
        #deactivates their button
        piececounter = -1
        for piece in newgameboard.pieces_list:
            #for each piece in the received game board
            piececounter += 1
            client.gameboard.pieces_list[piececounter].money = piece.money
            client.gameboard.pieces_list[piececounter].board_number = piece.board_number
            #print(client.pieceslist[piececounter].board_number)
            client.gameboard.pieces_list[piececounter].jailcount = piece.jailcount
            if newgameboard.rollmove == True:
                client.gameboard.pieces_list[piececounter].place_x = piece.place_x
                client.gameboard.pieces_list[piececounter].place_y = piece.place_y
                for y in pieces_list:
                    if y.board_number == client.gameboard.pieces_list[piececounter].board_number and y.board_number != 0 and client.gameboard.pieces_list[piececounter].name != y.name:
                        if client.gameboard.pieces_list[piececounter].board_number <=10:
                            client.gameboard.pieces_list[piececounter].place_y = y.place_y - 30
                        if client.gameboard.pieces_list[piececounter].board_number >=11 and client.gameboard.pieces_list[piececounter].board_number <=20:
                            client.gameboard.pieces_list[piececounter].place_x = y.place_x + 30
                        if client.gameboard.pieces_list[piececounter].board_number >=21 and client.gameboard.pieces_list[piececounter].board_number <=30:
                            client.gameboard.pieces_list[piececounter].place_y = y.place_y + 30
                        if client.gameboard.pieces_list[piececounter].board_number >=31:
                            client.gameboard.pieces_list[piececounter].place_x = y.place_x - 30
                            #passes all values of the new pieces, money, jail, coordinates
        boardcounter = -1
        for place in newgameboard.board_places_list:
            boardcounter += 1
            client.gameboard.board_places_list[boardcounter].owner = place.owner
            client.gameboard.board_places_list[boardcounter].completeset = place.completeset
            client.gameboard.board_places_list[boardcounter].housenumber = place.housenumber
            #for each place in the new board sets the values of owner complete set and house number

        #make client.housefunc to check for house changes and put houses on gui
        client.dicefunc()
        client.checkfunc()
        client.housesfunc()
        client.tradecheck()
        client.guitradefunc()
        #runs gui functions in client_file

    client_socket.close()
    #closes current socket

def newmovefunc():
    #if they hit button it sets values to true
    client.gameboard.sendshit = True
    client.gameboard.sentalready = False

#makes the players buttons window and buttons
playerturngui = Tk()
playerturngui.geometry('350x200+300+300')
playerturngui.title('Player Turn')
#players turn gui with controls
rollbut = Button(playerturngui, height=5, width=5, text='roll', command=newmovefunc)
rollbut.place(x = '1', y = '1')
managepropbutton = Button(playerturngui, height=5, width=5, text='manage', command=managefunc)
managepropbutton.place(x='100', y='1')
tradebutton = Button(playerturngui, height=5, width=5, text='trade', command=tradefunc)
tradebutton.place(x='200', y='1')
rollbut['state'] = DISABLED

def main_loop():
    while True:
        #main thread checking if any values have changed and the client hit one of their buttons and needs to send it to client
        if client.gameboard.turn == client.monkeynum:
            if client.gameboard.activebutton == False:
                client.gameboard.activebutton = True
                rollbut['state'] = NORMAL

        if client.gameboard.sendshit == True:
            if client.gameboard.sentalready == False:
                client.gameboard.sentalready = True
                message = 'button pressed' + str(client.monkeynum) + str(0)
                client_socket.send(message.encode())
                rollbut['state'] = DISABLED
        if client.gameboard.purchasedprop == True:
            client.gameboard.purchasedprop = False
            message = 'purchasedpropp' + str(client.monkeynum) + str(client.gameboard.whichproperty) #the property number
            client_socket.send(message.encode())
        if client.gameboard.purchasedcomp == True:
            client.gameboard.purchasedcomp = False
            message = 'purchasedpropc' + str(client.monkeynum) + str(client.gameboard.whichproperty)
            client_socket.send(message.encode())
        if client.gameboard.purchasedbus == True:
            client.gameboard.purchasedbus = False
            message = 'purchasedpropb' + str(client.monkeynum) + str(client.gameboard.whichproperty)
            client_socket.send(message.encode())
        if client.gameboard.chance == True:
            client.gameboard.chance = False
            message = 'chance card___' + str(client.monkeynum) + str(client.gameboard.whichchance)
            client_socket.send(message.encode())
        if client.gameboard.sendhouses == True:
            client.gameboard.sendhouses = False
            message = 'add houses____' + str(client.monkeynum) + str(12) + gameboard.whichhouses ##client str
            client_socket.send(message.encode())
        if client.gameboard.trade == True:
            client.gameboard.trade = False
            message = 'tradetrade____' + str(client.monkeynum) + str(client.gameboard.tradeto) + '                                                  ' + str(client.gameboard.whattrade)
            client_socket.send(message.encode())
        if client.gameboard.accepttrade == True:
            client.gameboard.accepttrade = False
            message = 'accepttrade___' + str(client.monkeynum) + str(client.gameboard.gametradefrom)
            client_socket.send(message.encode())
        if client.gameboard.mortgage == True:
            client.gameboard.mortgage = False
            message = 'mortgage______' + str(client.monkeynum) + str(client.gameboard.mortgagewhich)
            client_socket.send(message.encode())
        if client.gameboard.gameover == True:
            playerturngui.destroy()
            for widgets in gui.children():
                widgets.destroy()
            gui.config(bg='blue')
            winlb = Label(gui, text='congradulations ' + str(client.gameboard.pieces_list[client.monkeynum].name) + 'You won')
#all values checking game over chance, property, trade
        time.sleep(1)


host = '10.2.7.73'
port = 8080
#sets host and port to connect client server

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((host, port))
#connects the client to server

# Start a separate thread to continuously listen for data from the server
receive_thread = threading.Thread(target=receive_data, args=(client_socket,))
receive_thread.start()
#starts receive thread to check for receiving

mainloop_thread = threading.Thread(target=main_loop)
mainloop_thread.start()
#starts mainloop thread to check for if client made a change

playerturngui.mainloop()
client_socket.close()
#main loop for gui and close socket