import socket
import pickle
from threading import Thread
import random
from theobjects import *
#import all modules and packages needed

# Maintain a list of all client sockets to send the object to all clients
clients = []

def client_thread(conn):
    # Add the new client socket to the clients list
    clients.append(conn)
    #on connection add the client connected to list of clients

    while True:
        #lwayds trying to receive date
        data = conn.recv(1024)
        if not data:
            break
            #if no data is received it breaks and continues
        message = data.decode()
        #if it does receive the message it decodes the data
        print(message)
        word = message[:14]
        #the word is the first part or the action it is the first 14 characters in the word
        numid = int(message[14:15])
        #the numid is the client number that sent it
        propnum = int(message[15:17])
        #propnum is the number of property if there is a property that is purchased
        a1 = message[17:19]
        a2 = message[19:22]
        a3 = message[22:25]
        a4 = message[25:28]
        a5 = message[28:33]
        a6 = message[33:39]
        tt = message[65:105]
        #the a are properties houses being added if they are and tt is a trade

        if a1 != '' and a1 != ' ' and a1 != '  ':
            #if there is no houses it does not add
            a1 = int(a1)
            a2 = int(a2)
            a3 = int(a3)
            a4 = int(a4)
        if a5 != '':
            #for groups of there properties check if there are more houses
            try:
                a5 = int(a5)
                a6 = int(a6)
            except:
                pass
        if a5 == '':
            tri = 2
            #tri is the number of properties in the group set to 2 if there are no houses for 3
        else:
            tri = 3
            #if not it is 3
        print(propnum)

        if word == 'button pressed':
            #if the word in the message from client is button pressed they pressed roll
            gameboard.rollmove = True
            #sets roll to true
            rand1 = random.randint(1, 1)
            rand2 = random.randint(0, 0)
            gameboard.dice1 = rand1
            gameboard.dice2 = rand2
            #gets random numbers for dice
            totalrand = rand1 + rand2
            #adds together for total piece movement
            if rand1 != rand2:
                gameboard.turn += 1 #1
                if gameboard.turn == 2:
                    gameboard.turn = 0
                    #if they are not doubles updates turn and last turn below
                gameboard.lastturn += 1 #1
                if gameboard.lastturn == 2:
                    gameboard.lastturn = 0
            if gameboard.pieces_list[numid].jailcount == 0 or rand1 == rand2:
                gameboard.pieces_list[numid].board_number += totalrand
                #if they are not in jail or doubles they move their boardnumber to reflected added roll
                gameboard.pieces_list[numid].jailcount = 0
                #and it sets jail to 0
            else:
                gameboard.pieces_list[numid].jailcount -= 1
                #if they are in jail and not doubles their jail counter minus 1
            if gameboard.pieces_list[numid].board_number > 40:
                gameboard.pieces_list[numid].board_number -= 40
                #if they have a board number of greater than 40 it minus 40 so that the board number is reset
            for place in gameboard.board_places_list:
                #for every place in the list of board placeds
                if place.number == gameboard.pieces_list[numid].board_number:
                    #if the piece that rolled is on that place
                    if gameboard.pieces_list[numid].jailcount == 0:
                        #if they are not in jail
                        gameboard.pieces_list[numid].place_x = place.cordx
                        gameboard.pieces_list[numid].place_y = place.cordy
                        #sets their coordinates to that of the place
                        if place.number == 4:
                            gameboard.pieces_list[numid].money -= 200
                            #if the place is 4 it is tax minue 200 from money
                        if place.number == 38:
                            gameboard.pieces_list[numid].money -= 100
                            #if it is 38 it is tax minus 100
                        if place.number == 30:
                            print('they landed on jail')
                            #if it is 30 they are in jail
                            gameboard.pieces_list[numid].jailcount = 3
                            gameboard.pieces_list[numid].board_number = 10
                            gameboard.pieces_list[numid].place_x = 60
                            gameboard.pieces_list[numid].place_y = 660
                        if place.propertytype == 'property':
                            if place.subpropertytype == 'property':
                                #If the type is a property
                                if place.owner == 'no':
                                    pass
                                if place.owner != 'no':
                                    #if it is owner and they do not own it
                                    if place.owner != numid:
                                        if place.mortgaged == False:
                                            #if it is not mortgaged
                                            if place.housenumber == 1:
                                                rrent = place.rent1
                                            elif place.housenumber == 2:
                                                rrent = place.rent2
                                            elif place.housenumber == 3:
                                                rrent = place.rent3
                                            elif place.housenumber == 4:
                                                rrent = place.rent4
                                            elif place.housenumber == 5:
                                                rrent = place.rent5
                                            elif place.housenumber == 0:
                                                rrent = place.rent0
                                                #checks for number of houses for rent
                                            if gameboard.pieces_list[numid].money < rrent:
                                                gameboard.pieces_list[numid].money = 0
                                                #if they have less than rent
                                                gameboard.pieces_list[numid].placex = -1000
                                                gameboard.pieces_list[numid].placey = -1000
                                                #eliminate piece
                                                gameboard.gameover = True
                                                #game over
                                            else:
                                                gameboard.pieces_list[numid].money -= rrent
                                                #if they have enough to pay it minus from teir money rent
                                                gameboard.pieces_list[place.owner].money += rrent
                                                #adds to the owner of the property the rent
                            if place.subpropertytype == 'bus':
                                print('bus')
                                #if bus
                                if place.owner == 'no':
                                    pass
                                if place.owner != 'no':
                                    if place.owner != numid:
                                        #if it is owner and not by them
                                        if gameboard.pieces_list[place.owner].busnumber == 1:
                                            busrent = 25
                                            print('they own 1')
                                        elif gameboard.pieces_list[place.owner].busnumber == 2:
                                            busrent = 50
                                        elif gameboard.pieces_list[place.owner].busnumber == 3:
                                            busrent = 100
                                        elif gameboard.pieces_list[place.owner].busnumber == 4:
                                            busrent = 200
                                        #depending on number of buses determines rent value
                                        gameboard.pieces_list[numid].money -= busrent
                                        gameboard.pieces_list[place.owner].money += busrent
                                        #exchange rent values
                            if place.subpropertytype == 'company':
                                print('company')
                                #if it is a company
                                if place.owner == 'no':
                                    pass
                                if place.owner != 'no':
                                    if place.owner != numid:
                                        #if it is owner and not by them
                                        if gameboard.pieces_list[place.owner].compnumber == 1:
                                            comprent = totalrand * 5
                                            #if they own one the rent is their roll times 5
                                        elif gameboard.pieces_list[place.owner].compnumber == 2:
                                            comprent = totalrand * 10
                                            #if they own both it is times 10
                                        gameboard.pieces_list[numid].money -= comprent
                                        gameboard.pieces_list[place.owner].money += comprent
                                        #exchnages rent

        if word == 'purchasedpropp':
            #if they bought a property
            gameboard.board_places_list[propnum].owner = numid
            gameboard.pieces_list[numid].money -= gameboard.board_places_list[propnum].cost
            #sets them the owner minus money from cost of property
            setcounter = 0
            for place in gameboard.board_places_list:
                if place.owner == numid and place.colourset == gameboard.board_places_list[propnum].colourset:
                    savedcolourset = place.colourset
                    setcounter += 1
                    #checks the colour set of that property
            if gameboard.board_places_list[propnum].colourset == 0 or gameboard.board_places_list[propnum].colourset == 7:
                if setcounter == 2:
                    for place in gameboard.board_places_list:
                        if place.colourset == savedcolourset:
                            place.completeset = True
                            print(place.completeset)
                            print(gameboard.board_places_list[propnum].completeset)
                            print('it is complete')
                            #checks if it is now a complete colour set and they own all of the property in that set
            else:
                if setcounter == 3:
                    for place in gameboard.board_places_list:
                        if place.colourset == savedcolourset:
                            place.completeset = True
                            #for three sets complete set to True

        if word == 'purchasedpropc':
            gameboard.board_places_list[propnum].owner = numid
            gameboard.pieces_list[numid].money -= gameboard.board_places_list[propnum].cost
            gameboard.pieces_list[numid].compnumber += 1
            #if they purchased company they add one to the counter of companies owned and minus cost and set owner
        if word == 'purchasedpropb':
            gameboard.board_places_list[propnum].owner = numid
            gameboard.pieces_list[numid].money -= gameboard.board_places_list[propnum].cost
            gameboard.pieces_list[numid].busnumber += 1
            #if they purchased bus they add one to the counter of bus owned and minus cost and set owner
        if word == 'chance card___':
            #if it is a chance card they got
            gameboard.rollmove = True
            #sets roll to true
            gameboard.pieces_list[numid].money += gameboard.chestlist[propnum].moneycom
            #sets the money of piece to chest card money value
            if gameboard.chestlist[propnum].movecom != 'no':
                gameboard.pieces_list[numid].board_number = gameboard.chestlist[propnum].movecom
                for place in gameboard.board_places_list:
                    if place.number == gameboard.pieces_list[numid].board_number:
                        gameboard.pieces_list[numid].place_x = place.cordx
                        gameboard.pieces_list[numid].place_y = place.cordy
                        #if there is movement in card sets coordinates and place to that of the card
        if word == 'mortgage______':
            if gameboard.board_places_list[propnum].mortgaged == False:
                gameboard.board_places_list[propnum].mortgaged = True
                print(propnum, 'is this mortgaged')
                gameboard.pieces_list[numid].money += 50
                #if it is mortgaged add money sets mortgage to true
            else:
                gameboard.board_places_list[propnum].mortgaged = False
                gameboard.pieces_list[numid].money -= 50
                #if it is not mortgaged sets to false and takes away money
        if word == 'tradetrade____':
            #if it is a trade
            gameboard.gametrade = True
            gameboard.gametradefrom = numid
            gameboard.gametradeto = propnum
            gameboard.gametradewhat = tt
            gameboard.savedtrade = tt
            #sets the trade values to true and what the trade is and who the trade is going to
            #gametradewhat =
            #for varfrom in tfromlist:
                #for place in gameboard.board_places_list:
                    #if place.number == varfrom:
                        #if place.owner == propnum:
        if word == 'accepttrade___':
            #if they are accepting the trade
            totaltradelist = gameboard.savedtrade.split('                    ')
            #it splits the trade value to see what is given and taken
            tradefrom = list(totaltradelist[0])
            tradeto = list(totaltradelist[1])
            #makes it a list
            for fitem in tradefrom:
                if fitem == ' ' or fitem == ',' or fitem == '[' or fitem == ']':
                    tradefrom.remove(fitem)
            for fitem in tradefrom:
                if fitem == ' ' or fitem == '[':
                    tradefrom.remove(fitem)
            for titem in tradeto:
                if titem == ' ' or titem == ',' or titem == '[' or titem == ']':
                    tradeto.remove(titem)
            for titem in tradeto:
                if titem == ' ':
                    tradeto.remove(titem)
            print(tradefrom)
            print(tradeto)
            #removes useless syntax from the lists

            for tff in tradefrom:
                print(tff)
                print(numid)
                gameboard.board_places_list[int(tff)].owner = int(numid)
                #changes owner of sets
            for ttt in tradeto:
                print(ttt)
                print(propnum)
                gameboard.board_places_list[int(ttt)].owner = int(propnum)
                #changes owner of set
            gameboard.guitrade = True
            #set the guitrade to true to change the colours of property
        if word == 'add houses____':
            #if they are adding houses
            totalcost = 0
            if tri == 2:
                for c in range(0, a2):
                    totalcost += gameboard.board_places_list[a1].housecost
                for d in range(0, a4):
                    totalcost += gameboard.board_places_list[a3].housecost
                gameboard.board_places_list[a1].housenumber = a2
                gameboard.board_places_list[a3].housenumber = a4
                #receives amount adding and adds cost and sets housenymber
            if tri == 3:
                for c in range(0, a2):
                    totalcost += gameboard.board_places_list[a1].housecost
                for d in range(0, a4):
                    totalcost += gameboard.board_places_list[a3].housecost
                for e in range(0, a6):
                    totalcost += gameboard.board_places_list[a5].housecost
                gameboard.board_places_list[a1].housenumber = a2
                gameboard.board_places_list[a3].housenumber = a4
                gameboard.board_places_list[a5].housenumber = a6
                #adds cost and sets house number

            gameboard.pieces_list[numid].money -= totalcost
            #minus total cost from that piece

        for client in clients:
            client.send(pickle.dumps(gameboard))
            #for every client in the list it sends the new object of the game to all clients
        gameboard.gametrade = False
        gameboard.rollmove = False
        #reset sthe roll and trade to False
    conn.close()
    #closes that connection
#for trades, make it so that server sends to all and clients will check if they are the one the trade is being posed to.
host = '10.2.7.73'
port = 8080
#host and port for server

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((host, port))
server_socket.listen(5)
#cosket thread makes the sockey listen on a port

print(f'Server started on {host}:{port}')
#prints starterd

while True:
    #always trying to receive a client and add their socket
    conn, addr = server_socket.accept()
    print(f'Connected by {addr}')
    thread = Thread(target=client_thread, args=(conn,))
    thread.start()