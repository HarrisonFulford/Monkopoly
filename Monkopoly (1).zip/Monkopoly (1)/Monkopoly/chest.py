
class chest:
    def __init__(self, lbtext, movecom, moneycom, jailcom):
        self.lbtext = lbtext
        self.movecom = movecom
        self.moneycom = moneycom
        self.jailcom = jailcom
        
#class for objects for each chest piece, contains text, movement if there is, money change, and jail 
chestlist = [chest('You were late coming in from lunch\n go to the office', 24, -0, 'no'),
             chest('Advance to Smith class to get some cokes', 0, -0, 'no'),
             chest('Monkey fees, lose 50 cokes', 'no', -50, 'no'),
             chest('Brayden needs your muck\n lose 25 cokes', 'no', -25, 'no'),
             chest('You hate yourself\n go to Scarborough', 11, -0, 'no'),
             chest('You decided you were tired of cokes\n go to the Pepsi company', 12, -0, 'no'),
             chest('You completed an assignment on time\n receive 50 cokes', 'no', +50, 'no'),
             chest('Bhavjeet wants you to be his Hartag\n he gave you 200 cokes for it', 'no', +200, 'no'),
             chest('Smith deemed you king of the monkets\n Receive 100 cokes', 'no', +100, 'no'),
             chest('Take a trip on Bus Wayne', 5, -0, 'no'),
             chest('You a ugly ah monkey and won\n second last in a beauty contest\n collect 10 cokes', 'no', +10, 'no'),
             chest('Some monkey robbed a class\n and dropped the cokes\n collect 150 cokes', 'no', +150, 'no'),
             chest('You brought your coke into class\n and Mcrae took it\n lose 100 cokes', 'no', -100, 'no')]