from tkinter import *
import tkinter as tk
from PIL import ImageTk, Image
from pieces import *
#from boardplaces import boardplaces
from chest import chest
from dice import dice

gui = Tk()
gui.geometry("950x750")
gui.title('Monkopoly')
doubleslb = Label(gui, text='DOUBLES!', height =1, width=10, bg='#D5E8D4', font=('Cooper Std Black', 30))

frame = Frame(gui, width=2000, height=2000)
frame.pack()
frame.place(anchor='center', relx=0.5, rely=0.5)
boardimg = Image.open('monboard16.jpg')
image2 = boardimg.resize((737, 738),Image.BICUBIC)
boardimg2=ImageTk.PhotoImage(image2)
boardlabel = Label(frame, image = boardimg2)
boardlabel.pack()

bluemoney = tk.PhotoImage(file='monkeymoneycokeb.png')
bluemoneylb = tk.Label(gui, image=bluemoney)
bluemoneylb.place(x=1, y=1)
bimg = Image.open('monkeyfaceblue4.png')
bimg2 = bimg.resize((65, 60),Image.BICUBIC)
bimg3=ImageTk.PhotoImage(bimg2)
blabel = Label(gui, image = bimg3)
blabel.place(x=18, y=20)
redmoney = tk.PhotoImage(file='monkeymoneyr4.png')
redmoneylb = tk.Label(gui, image=redmoney)
redmoneylb.place(x=1, y=626)
rimg = Image.open('newmonred.png')
rimg2 = rimg.resize((65, 60),Image.BICUBIC)
rimg3=ImageTk.PhotoImage(rimg2)
rlabel = Label(gui, image = rimg3)
rlabel.place(x=18, y=646)
greenmoney = tk.PhotoImage(file='monkeymoneyg4.png')
greenmoneylb = tk.Label(gui, image=greenmoney)
greenmoneylb.place(x=845, y=1)
gimg = Image.open('newmongreen.png')
gimg2 = gimg.resize((65, 60),Image.BICUBIC)
gimg3=ImageTk.PhotoImage(gimg2)
glabel = Label(gui, image = gimg3)
glabel.place(x=863, y=20)
pinkmoney = tk.PhotoImage(file='monkeymoneyp4.png')
pinkmoneylb = tk.Label(gui, image=pinkmoney)
pinkmoneylb.place(x=845, y=626)
pimg = Image.open('newmonpink.png')
pimg2 = pimg.resize((65, 60),Image.BICUBIC)
pimg3=ImageTk.PhotoImage(pimg2)
plabel = Label(gui, image = pimg3)
plabel.place(x=863, y=646)

monblueimg = tk.PhotoImage(file='monkeyfaceblue4.png')
mongreenimg = tk.PhotoImage(file='newmongreen.png')
monredimg = tk.PhotoImage(file='newmonred.png')
monpinkimg = tk.PhotoImage(file='newmonpink.png')
monbluelabel = tk.Label(frame, image = monblueimg, width=26, height=24)
monbluelabel.place(x = '640', y = '715')
mongreenlabel = Label(frame, image=mongreenimg)
mongreenlabel.place(x = '640', y = '690')
monredlabel = Label(frame, image=monredimg)
monredlabel.place(x = '640', y = '665')
monpinklabel = Label(frame, image=monpinkimg)
monpinklabel.place(x = '640', y = '640')

bmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='blue', fg='white')
bmoneyvallb.place(x=22, y=84)
rmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='red', fg='white')
rmoneyvallb.place(x=22, y=710)
gmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='#28DC28', fg='white')
gmoneyvallb.place(x=868, y=84)
pmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='#C525E2', fg='white')
pmoneyvallb.place(x=868, y=710)

dice1img = tk.PhotoImage(file='dice1.png')
dice1lb = tk.Label(gui, image=dice1img)
dice1lb2 = tk.Label(gui, image=dice1img)
dice2img = tk.PhotoImage(file='dice2.png')
dice2lb = tk.Label(gui, image=dice2img)
dice2lb2 = tk.Label(gui, image=dice2img)
dice3img = tk.PhotoImage(file='dice3.png')
dice3lb = tk.Label(gui, image=dice3img)
dice3lb2 = tk.Label(gui, image=dice3img)
dice4img = tk.PhotoImage(file='dice4.png')
dice4lb = tk.Label(gui, image=dice4img)
dice4lb2 = tk.Label(gui, image=dice4img)
dice5img = tk.PhotoImage(file='dice5.png')
dice5lb = tk.Label(gui, image=dice5img)
dice5lb2 = tk.Label(gui, image=dice5img)
dice6img = tk.PhotoImage(file='dice6.png')
dice6lb = tk.Label(gui, image=dice6img)
dice6lb2 = tk.Label(gui, image=dice6img)

#caledonimg = tk.PhotoImage(file='caledon.png')
#caledonlb = tk.Label(gui, image=caledonimg)
#caledonlb.place(x=1, y=1)

dicelist = [dice(1, dice1lb, dice1lb2),
            dice(2, dice2lb, dice2lb2),
            dice(3, dice3lb, dice3lb2),
            dice(4, dice4lb, dice4lb2),
            dice(5, dice5lb, dice5lb2),
            dice(6, dice6lb, dice6lb2)]
activedicelist = [dice1lb, dice1lb2]

pieceslist = [pieces(1, 'yes', "Blue Monkey", 640, 715, 0, monbluelabel, 1500, bmoneyvallb),
              pieces(2, 'no', "Green Monkey", 640, 690, 0, mongreenlabel, 1500, gmoneyvallb),
              pieces(3, 'no', "Red Monkey", 640, 665, 0, monredlabel, 1500, rmoneyvallb),
              pieces(4, 'no', "Pink Monkey", 640, 640, 0, monpinklabel, 1500, pmoneyvallb)]

chestlist = [chest('You were late coming in from lunch\n go to the office', 24, -0, 'no'),
             chest('Advance to Smith class to get some cokes', 0, -0, 'no'),
             chest('Monkey fees, lose 50 cokes', 'no', -50, 'no'),
             chest('Brayden needs your muck\n lose 25 cokes', 'no', -25, 'no'),
             chest('You hate yourself\n go to Scarborough', 11, -0, 'no'),
             chest('You decided you were tired of cokes\n go to the Pepsi company', 12, -0, 'no'),
             chest('You completed an assignment on time\n receive 50 cokes', 'no', +50, 'no'),
             chest('Bhavjeet wants you to be his Hartag\n he gave you 200 cokes for it', 'no', +200, 'no'),
             chest('Smith deemed you king of the monkets\n Receive 100 cokes', 'no', +100, 'no'),
             chest('Go back three spaces', '-3', -0, 'no'),
             chest('Go back three spaces', '-3', -0, 'no'),
             chest('Take a trip on Bus Wayne', 5, -0, 'no'),
             chest('You a ugly ah monkey and won\n second last in a beauty contest\n collect 10 cokes', 'no', +10, 'no'),
             chest('Some monkey robbed a class\n and dropped the cokes\n collect 150 cokes', 'no', +150, 'no'),
             chest('You brought your coke into class\n and Mcrae took it\n lose 100 cokes', 'no', -100, 'no')]

def newmovefunc():
    dice1 = random.randint(1,6)
    dice2 = random.randint(1,6)
    for item in activedicelist:
        item.place_forget()
    activedicelist.clear()
    for z in dicelist:
        if z.dicenum == dice1:
            z.dicelb.place(x=340, y=560)
            activedicelist.append(z.dicelb)
        if z.dicenum == dice2:
            z.dicelb2.place(x=380, y=560)
            activedicelist.append(z.dicelb2)
    inp = dice1 + dice2
    for x in pieceslist:
        if x.turn == 'yes':
            pieces.rollfunc(x)


            break
playerturngui = Tk()
playerturngui.geometry('350x200+300+300')
playerturngui.title('Player Turn')
rollbut = Button(playerturngui, height=5, width=5, text='roll', command=newmovefunc)
rollbut.place(x = '1', y = '1')

#lb.place(x='100', y='1')
def destroyfunc():
    gui.destroy()
    playerturngui.destroy()

gui.resizable(False, False)
playerturngui.resizable(False, False)
def nah():
    pass
playerturngui.wm_protocol("WM_DELETE_WINDOW", nah)
gui.wm_protocol("WM_DELETE_WINDOW", destroyfunc)
playerturngui.mainloop()
gui.mainloop()


