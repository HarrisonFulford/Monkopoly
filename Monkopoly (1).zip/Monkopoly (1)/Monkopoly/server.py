# Import necessary modules
import socket
from _thread import *
import sys
import random
import select

# Set the IP address and port number for the server
server = "172.20.10.4"
port = 5555
# Initialize the client counter to 0
client_count = 0
clients = []

# Create a socket object and attempt to bind to the specified IP address and port
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.bind((server, port))
except socket.error as e:
    str(e)

# Set the socket to listen for incoming connections and print a message to the console
s.listen(2)
print("Waiting for a connection, Server Started")

# Define a function to handle each incoming connection in a separate thread
def threaded_client(conn):
    # Use the global client_count variable to keep track of the number of clients
    global client_count
    # Increment the client count
    client_count += 1
    # Assign a unique client ID to the connected client
    client_id = f"client {client_count}"
    # Send a "Connected" message to the client along with its assigned client ID
    conn.send(str.encode(f"connected {client_id}"))
    reply = ""
    clients.append(conn)
    while True:
        try:
            # Receive data from the client
            data = ''
            data = conn.recv(2048)
            reply = data.decode("utf-8")

            if not data:
                # If no data is received, print a message and break out of the loop
                print(f"{client_id} Disconnected")
                break
            else:
                print(f"Received from client {client_id}: {reply}")
                if 'rolled' in reply:
                    newreply = random.randint(2,12)

                else:
                    newreply = 'nope'

                for client in clients:
                    client.sendall(str.encode(f"{client_id}: {newreply}"))


        except:
            # If an exception is raised, break out of the loop
            break
    clients.remove(conn)
    # Print a message and close the connection
    print(f"{client_id} Lost connection")
    conn.close()

# Set up an infinite loop to accept incoming connections and create a new thread for each one
while True:
    # Accept an incoming connection
    conn, addr = s.accept()
    # Print a message indicating that the server is connected to the client
    print("Connected to:", addr)

    # Start a new thread to handle the connection
    start_new_thread(threaded_client, (conn,))
