import random 
from boardplaces import boardplaces
from boardplaces import boardplaceslist
from Labels import *

class pieces:
    def __init__(self, piecenumber, turn, name, placex, placey, boardnumber, label, money, moneylabel, vertcolour, horcolour, busnumber, compnumber, asset):
        self.piecenumber = piecenumber
        self.name = name
        self.turn = turn
        self.placex = placex
        self.placey = placey
        self.boardnumber = boardnumber
        self.label = label
        self.money = money
        self.moneylabel = moneylabel
        self.vertcolour = vertcolour
        self.horcolour = horcolour
        self.busnumber = busnumber
        self.compnumber = compnumber
        self.asset = asset
#makes the class of pieces, which will create a new piece and hold all information needed to be a piece, such as their name and money

    def rollfunc(self): #roll method for that piece
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        inp = dice1 + dice2 #gets two random numbers and adds together
        self.boardnumber += inp #adds the rolls to the position
        if self.boardnumber >= 40:
            self.boardnumber -= 40 #resets the position to 0 if it is 40 which means they have made one complete rotation
            self.money += 200 #passed go add 200
            self.moneylabel.config(text = self.money) #change the money label to reflect money
        for item in boardplaceslist: 
            if item.number == self.boardnumber:
                self.placex = item.cordx #sets the piece coordinate to that board places coordinate
                self.placey = item.cordy
                self.label.place(x = self.placex, y = self.placey) #redraws the piece label at that coordinate
                for y in pieceslist:
                    if y.boardnumber == self.boardnumber and self.boardnumber != 0 and self.name != y.name: #if they land on the same board place as another player
                        if self.boardnumber <=10:
                            self.placey = y.placey - 30
                        if self.boardnumber >=11 and x.boardnumber <=20:
                            self.placex = y.placex + 30
                        if self.boardnumber >=21 and x.boardnumber <30:
                            self.placey = y.placey + 30
                        if self.boardnumber >=31:
                            self.placex = y.placex - 30
                self.label.place(x = self.placex, y = self.placey) 
                #displays there postion by 30 pixels so that one piece doesn't cover another
                
            break

pieceslist = [pieces(1, 'yes', "Blue Monkey", 640, 715, 0, monbluelabel, 1500, bmoneyvallb, vertbluelinelist, horbluelinelist, 0, 0, 0),
              pieces(2, 'no', "Green Monkey", 640, 690, 0, mongreenlabel, 1500, gmoneyvallb, vertgreenlinelist, horgreenlinelist, 0, 0, 0),
              pieces(3, 'no', "Red Monkey", 640, 665, 0, monredlabel, 1500, rmoneyvallb, vertredlinelist, horredlinelist, 0, 0, 0),
              pieces(4, 'no', "Pink Monkey", 640, 640, 0, monpinklabel, 1500, pmoneyvallb, vertpinklinelist, horpinklinelist, 0, 0, 0)]
#List of 4 pieces, names and all

piecelist2 = []
#new piecelist to add to when a new client joins
#client 0 joins and they become blue monkey and inherit all attributes in the last list