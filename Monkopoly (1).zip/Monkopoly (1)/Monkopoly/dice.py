from Labels import *
import Labels

class dice:
    def __init__(self, dicenum, dicelb, dicelb2):
        self.dicenum = dicenum
        self.dicelb = dicelb
        self.dicelb2 = dicelb2
        
#makes dice object with image for dice1 and dice2, and a number that matches each

dicelist = [dice(1, dice1lb, dice1lb2),
            dice(2, dice2lb, dice2lb2),
            dice(3, dice3lb, dice3lb2),
            dice(4, dice4lb, dice4lb2),
            dice(5, dice5lb, dice5lb2),
            dice(6, dice6lb, dice6lb2)]

activedicelist = [dice1lb, dice1lb2]