from mttkinter import *
#import mtTkinter as tk
from mttkinter import mtTkinter as tk
from tkinter import *
from PIL import ImageTk, Image
gui = Tk()
gui.geometry("950x750")
gui.title('Monkopoly')
doubleslb = Label(gui, text='H', height =1, width=10, bg='#D5E8D4', font=('Cooper Std Black', 30))
doubleslb.place(x=444, y =132)

frame = Frame(gui, width=2000, height=2000)
frame.pack()
frame.place(anchor='center', relx=0.5, rely=0.5)
#boardimg0 = ImageTk.PhotoImage(Image.open('monboard14.jpg'))
boardimg = Image.open('finalboard.png')
image2 = boardimg.resize((737, 738),Image.BICUBIC)
boardimg2=ImageTk.PhotoImage(image2)
boardlabel = Label(frame, image = boardimg2)
boardlabel.pack()
bluemoney = tk.PhotoImage(file='monkeymoneycokeb.png')
bluemoneylb = tk.Label(gui, image=bluemoney)
bluemoneylb.place(x=1, y=1)
bimg = Image.open('monkeyfaceblue4.png')
bimg2 = bimg.resize((65, 60),Image.BICUBIC)
bbut = PhotoImage(file='monkeyfaceblue4.png')
bimg3=ImageTk.PhotoImage(bimg2)
blabel = Label(gui, image = bimg3)
blabel.place(x=18, y=20)
redmoney = tk.PhotoImage(file='monkeymoneyr4.png')
redmoneylb = tk.Label(gui, image=redmoney)
redmoneylb.place(x=1, y=626)
rimg = Image.open('newmonred.png')
rimg2 = rimg.resize((65, 60),Image.BICUBIC)
rimg3=ImageTk.PhotoImage(rimg2)
rlabel = Label(gui, image = rimg3)
rlabel.place(x=18, y=646)
greenmoney = tk.PhotoImage(file='monkeymoneyg4.png')
greenmoneylb = tk.Label(gui, image=greenmoney)
greenmoneylb.place(x=845, y=1)
gimg = Image.open('newmongreen.png')
gimg2 = gimg.resize((65, 60),Image.BICUBIC)
gimg3=ImageTk.PhotoImage(gimg2)
glabel = Label(gui, image = gimg3)
glabel.place(x=863, y=20)
pinkmoney = tk.PhotoImage(file='monkeymoneyp4.png')
pinkmoneylb = tk.Label(gui, image=pinkmoney)
pinkmoneylb.place(x=845, y=626)
pimg = Image.open('newmonpink.png')
pimg2 = pimg.resize((65, 60),Image.BICUBIC)
pimg3=ImageTk.PhotoImage(pimg2)
plabel = Label(gui, image = pimg3)
plabel.place(x=863, y=646)

monblueimg = tk.PhotoImage(file='monkeyfaceblue4.png')
mongreenimg = tk.PhotoImage(file='newmongreen.png')
monredimg = tk.PhotoImage(file='newmonred.png')
monpinkimg = tk.PhotoImage(file='newmonpink.png')
monbluelabel = tk.Label(frame, image = monblueimg)
monbluelabel.place(x = '640', y = '715')
mongreenlabel = Label(frame, image=mongreenimg)
mongreenlabel.place(x = '640', y = '690')
monredlabel = Label(frame, image=monredimg)
monredlabel.place(x = '640', y = '665')
monpinklabel = Label(frame, image=monpinkimg)
monpinklabel.place(x = '640', y = '640')

bmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 20), bg='blue', fg='white')
bmoneyvallb.place(x=22, y=84)
rmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='red', fg='white')
rmoneyvallb.place(x=22, y=710)
gmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='#28DC28', fg='white')
gmoneyvallb.place(x=868, y=84)
pmoneyvallb = Label(gui, height = 1, width=4, text='1500', font=('Cooper Std Black', 24), bg='#C525E2', fg='white')
pmoneyvallb.place(x=868, y=710)

dice1img = tk.PhotoImage(file='dice1.png')
dice1lb = tk.Label(gui, image=dice1img)
dice1lb2 = tk.Label(gui, image=dice1img)
dice2img = tk.PhotoImage(file='dice2.png')
dice2lb = tk.Label(gui, image=dice2img)
dice2lb2 = tk.Label(gui, image=dice2img)
dice3img = tk.PhotoImage(file='dice3.png')
dice3lb = tk.Label(gui, image=dice3img)
dice3lb2 = tk.Label(gui, image=dice3img)
dice4img = tk.PhotoImage(file='dice4.png')
dice4lb = tk.Label(gui, image=dice4img)
dice4lb2 = tk.Label(gui, image=dice4img)
dice5img = tk.PhotoImage(file='dice5.png')
dice5lb = tk.Label(gui, image=dice5img)
dice5lb2 = tk.Label(gui, image=dice5img)
dice6img = tk.PhotoImage(file='dice6.png')
dice6lb = tk.Label(gui, image=dice6img)
dice6lb2 = tk.Label(gui, image=dice6img)

caledonimg = tk.PhotoImage(file='caledon.png')
miltonimg = tk.PhotoImage(file='milton.png')
angolaimg = tk.PhotoImage(file='angola.png')
somaliaimg = tk.PhotoImage(file='somalia.png')
chadimg = tk.PhotoImage(file='chad.png')
scarboroughimg = tk.PhotoImage(file='scarborough.png')
markhamimg = tk.PhotoImage(file='Markham.png')
primarycampusimg = tk.PhotoImage(file='primarycampus.png')
gcpimg = tk.PhotoImage(file='gcp.png')
mentorlobbyimg = tk.PhotoImage(file='mentorlobby.png')
bhavbarnimg = tk.PhotoImage(file='bhavbarn.png')
mentorgymimg = tk.PhotoImage(file='mentorgym.png')
northkoreaimg = tk.PhotoImage(file='northkorea.png')
mentorofficeimg = tk.PhotoImage(file='mentoroffice.png')
yehiapyramidimg = tk.PhotoImage(file='yehiapyramid.png')
egyptimg = tk.PhotoImage(file='egypt.png')
landdownunderimg = tk.PhotoImage(file='landdownunder.png')
evancampimg = tk.PhotoImage(file='evancamp.png')
greenwoodimg = tk.PhotoImage(file='greenwood.png')
oakvilleimg = tk.PhotoImage(file='oakville.png')
crystalcoveimg = tk.PhotoImage(file='crystalcove.png')
jungleofmonkeysimg = tk.PhotoImage(file='jungleofmonkeys.png')
smithbusimg = tk.PhotoImage(file='smithbus.png')
waynebusimg = tk.PhotoImage(file='waynebus.png')
danbusimg = tk.PhotoImage(file='danbus.png')
jeffbusimg = tk.PhotoImage(file='jeffbus.png')
pepsicompanyimg = tk.PhotoImage(file='pepsicompany.png')
cokecompanyimg = tk.PhotoImage(file='cokecompany.png')

allactivelineslist = []

managegui = tk.Toplevel()
managegui.geometry("930x420")
managegui.title('manage')
managegui.withdraw()

caledonimg2 = Image.open('caledon.png')
caledonimg3 = caledonimg2.resize((150, 172),Image.BICUBIC)
caledonimg4=ImageTk.PhotoImage(caledonimg3)
caledonsmalllb = tk.Label(managegui, image=caledonimg4)

miltonimg2 = Image.open('milton.png')
miltonimg3 = miltonimg2.resize((150, 172),Image.BICUBIC)
miltonimg4=ImageTk.PhotoImage(miltonimg3)
miltonsmalllb = tk.Label(managegui, image=miltonimg4)

angolaimg2 = Image.open('angola.png')
angolaimg3 = angolaimg2.resize((150, 172),Image.BICUBIC)
angolaimg4=ImageTk.PhotoImage(angolaimg3)
angolasmalllb = tk.Label(managegui, image=angolaimg4)

somaliaimg2 = Image.open('somalia.png')
somaliaimg3 = somaliaimg2.resize((150, 172),Image.BICUBIC)
somaliaimg4=ImageTk.PhotoImage(somaliaimg3)
somaliasmalllb = tk.Label(managegui, image=somaliaimg4)

chadimg2 = Image.open('chad.png')
chadimg3 = chadimg2.resize((150, 172),Image.BICUBIC)
chadimg4=ImageTk.PhotoImage(chadimg3)
chadsmalllb = tk.Label(managegui, image=chadimg4)

scarboroughimg2 = Image.open('scarborough.png')
scarboroughimg3 = scarboroughimg2.resize((150, 172),Image.BICUBIC)
scarboroughimg4=ImageTk.PhotoImage(scarboroughimg3)
scarboroughsmalllb = tk.Label(managegui, image=scarboroughimg4)

markhamimg2 = Image.open('Markham.png')
markhamimg3 = markhamimg2.resize((150, 172),Image.BICUBIC)
markhamimg4=ImageTk.PhotoImage(markhamimg3)
markhamsmalllb = tk.Label(managegui, image=markhamimg4)

primarycampusimg2 = Image.open('primarycampus.png')
primarycampusimg3 = primarycampusimg2.resize((150, 172),Image.BICUBIC)
primarycampusimg4=ImageTk.PhotoImage(primarycampusimg3)
primarycampussmalllb = tk.Label(managegui, image=primarycampusimg4)

gcpimg2 = Image.open('gcp.png')
gcpimg3 = gcpimg2.resize((150, 172),Image.BICUBIC)
gcpimg4=ImageTk.PhotoImage(gcpimg3)
gcpsmalllb = tk.Label(managegui, image=gcpimg4)

mentorlobbyimg2 = Image.open('mentorlobby.png')
mentorlobbyimg3 = mentorlobbyimg2.resize((150, 172),Image.BICUBIC)
mentorlobbyimg4=ImageTk.PhotoImage(mentorlobbyimg3)
mentorlobbysmalllb = tk.Label(managegui, image=mentorlobbyimg4)

bhavbarnimg2 = Image.open('bhavbarn.png')
bhavbarnimg3 = bhavbarnimg2.resize((150, 172),Image.BICUBIC)
bhavbarnimg4=ImageTk.PhotoImage(bhavbarnimg3)
bhavbarnsmalllb = tk.Label(managegui, image=bhavbarnimg4)

mentorgymimg2 = Image.open('mentorgym.png')
mentorgymimg3 = mentorgymimg2.resize((150, 172),Image.BICUBIC)
mentorgymimg4=ImageTk.PhotoImage(mentorgymimg3)
mentorgymsmalllb = tk.Label(managegui, image=mentorgymimg4)

northkoreaimg2 = Image.open('northkorea.png')
northkoreaimg3 = northkoreaimg2.resize((150, 172),Image.BICUBIC)
northkoreaimg4=ImageTk.PhotoImage(northkoreaimg3)
northkoreasmalllb = tk.Label(managegui, image=northkoreaimg4)

mentorofficeimg2 = Image.open('mentoroffice.png')
mentorofficeimg3 = mentorofficeimg2.resize((150, 172),Image.BICUBIC)
mentorofficeimg4=ImageTk.PhotoImage(mentorofficeimg3)
mentorofficesmalllb = tk.Label(managegui, image=mentorofficeimg4)

yehiapyramidimg2 = Image.open('yehiapyramid.png')
yehiapyramidimg3 = yehiapyramidimg2.resize((150, 172),Image.BICUBIC)
yehiapyramidimg4=ImageTk.PhotoImage(yehiapyramidimg3)
yehiapyramidsmalllb = tk.Label(managegui, image=yehiapyramidimg4)

egyptimg2 = Image.open('egypt.png')
egyptimg3 = egyptimg2.resize((150, 172),Image.BICUBIC)
egyptimg4=ImageTk.PhotoImage(egyptimg3)
egyptsmalllb = tk.Label(managegui, image=egyptimg4)

landdownunderimg2 = Image.open('landdownunder.png')
landdownunderimg3 = landdownunderimg2.resize((150, 172),Image.BICUBIC)
landdownunderimg4=ImageTk.PhotoImage(landdownunderimg3)
landdownundersmalllb = tk.Label(managegui, image=landdownunderimg4)

evancampimg2 = Image.open('evancamp.png')
evancampimg3 = evancampimg2.resize((150, 172),Image.BICUBIC)
evancampimg4=ImageTk.PhotoImage(evancampimg3)
evancampsmalllb = tk.Label(managegui, image=evancampimg4)

greenwoodimg2 = Image.open('greenwood.png')
greenwoodimg3 = greenwoodimg2.resize((150, 172),Image.BICUBIC)
greenwoodimg4=ImageTk.PhotoImage(greenwoodimg3)
greenwoodsmalllb = tk.Label(managegui, image=greenwoodimg4)

oakvilleimg2 = Image.open('oakville.png')
oakvilleimg3 = oakvilleimg2.resize((150, 172),Image.BICUBIC)
oakvilleimg4=ImageTk.PhotoImage(oakvilleimg3)
oakvillesmalllb = tk.Label(managegui, image=oakvilleimg4)

crystalcoveimg2 = Image.open('crystalcove.png')
crystalcoveimg3 = crystalcoveimg2.resize((150, 172),Image.BICUBIC)
crystalcoveimg4=ImageTk.PhotoImage(crystalcoveimg3)
crystalcovesmalllb = tk.Label(managegui, image=crystalcoveimg4)

jungleofmonkeysimg2 = Image.open('jungleofmonkeys.png')
jungleofmonkeysimg3 = jungleofmonkeysimg2.resize((150, 172),Image.BICUBIC)
jungleofmonkeysimg4=ImageTk.PhotoImage(jungleofmonkeysimg3)
jungleofmonkeyssmalllb = tk.Label(managegui, image=jungleofmonkeysimg4)
plusbutlist = []
def mandesfunc(plusbutlist = plusbutlist):
    #for widgets in managegui.winfo_children():
        #widgets.pack_forget()
    managegui.withdraw()
    for item in plusbutlist:
        item.destroy()

    plusbutlist = []

managegui.wm_protocol("WM_DELETE_WINDOW", mandesfunc)

universallinelist = []

treeimg = tk.PhotoImage(file='tree3.png')
treelist = []
for z in range(1, 96):
    treelb = tk.Label(gui, image=treeimg)
    treelist.append(treelb)

tree90img = tk.PhotoImage(file='tree390.png')
tree90list = []
for z in range(1, 96):
    tree90lb = tk.Label(gui, image=tree90img)
    tree90list.append(tree90lb)


hotel = tk.PhotoImage(file='hotel4.png')
hotellist = []
for a in range(1,96):
    hotellb = tk.Label(gui, image=hotel)
    hotellist.append(hotellb)

hotel90 = tk.PhotoImage(file='hotel490.png')
hotel90list = []
for a in range(1,96):
    hotel90lb = tk.Label(gui, image=hotel90)
    hotel90list.append(hotel90lb)

vertbluelinelist = []
for x in range(0,272):
    blueline = Label(frame, height =3, width=1, bg='blue')
    vertbluelinelist.append(blueline)

horbluelinelist = []
for x in range(0,272):
    horblueline = Label(frame, height =1, width=5, bg='blue')
    horbluelinelist.append(horblueline)

vertgreenlinelist = []
for x in range(0,272):
    greenline = Label(frame, height =3, width=1, bg='green')
    vertgreenlinelist.append(greenline)

horgreenlinelist = []
for x in range(0,272):
    horgreenline = Label(frame, height =1, width=5, bg='green')
    horgreenlinelist.append(horgreenline)

vertredlinelist = []
for x in range(0,272):
    redline = Label(frame, height =3, width=1, bg='red')
    vertredlinelist.append(redline)

horredlinelist = []
for x in range(0,272):
    horredline = Label(frame, height =1, width=5, bg='red')
    horredlinelist.append(horredline)

vertpinklinelist = []
for x in range(0,272):
    pinkline = Label(frame, height =3, width=1, bg='purple')
    vertpinklinelist.append(pinkline)

horpinklinelist = []
for x in range(0,272):
    horpinkline = Label(frame, height =1, width=5, bg='purple')
    horpinklinelist.append(horpinkline)
#gui.mainloop()
#makes all the graphics

#def redraw(y):
    #y.label.place(x = '640', y = '715')