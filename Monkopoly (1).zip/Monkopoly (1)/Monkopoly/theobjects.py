#list of all objects
class game:
    def __init__(self, turn, lastturn, dice1, dice2, activebutton, sentalready, sendshit, check, purchasedprop, purchasedbus, purchasedcomp, whichproperty, chance, whichchance, alreadychance, whichhouses, sendhouses, trade, clienttradefrom, clienttradeto, clientwhattrade, gametrade, gametradefrom, gametradeto, gametradewhat, accepttrade, savedtrade, accepttradeto, guitrade, rollmove, mortgage, mortgagewhich, gameover, pieces_list, board_places_list, chestlist, won):
        self.turn = turn
        self.lastturn = lastturn
        self.dice1 = dice1
        self.dice2 = dice2
        self.activebutton = activebutton
        self.sentalready = sentalready
        self.sendshit = sendshit
        self.check = check
        self.purchasedprop = purchasedprop
        self.purchasedbus = purchasedbus
        self.purchasedcomp = purchasedcomp
        self.whichproperty = whichproperty
        self.chance = chance
        self.whichchance = whichchance
        self.alreadychance = alreadychance
        self.whichhouses = whichhouses
        self.sendhouses = sendhouses
        self.trade = trade
        self.clienttradefrom = clienttradefrom
        self.clienttradeto = clienttradeto
        self.clientwhattrade = clientwhattrade
        self.gametrade = gametrade
        self.gametradefrom = gametradefrom
        self.gametradeto = gametradeto
        self.gametradewhat = gametradewhat
        self.accepttrade = accepttrade
        self.savedtrade = savedtrade
        self.accepttradeto = accepttradeto
        self.guitrade = guitrade
        self.rollmove = rollmove
        self.mortgage = mortgage
        self.mortgagewhich = mortgagewhich
        self.gameover = gameover
        self.pieces_list = pieces_list
        self.board_places_list = board_places_list
        self.chestlist = chestlist
        self.won = won
#game object tracks values in the game particular to no piece or place

class Piece:
    def __init__(self, piece_number, turn, name, place_x, place_y, board_number, money, busnumber, compnumber, jailcount):
        self.piece_number = piece_number
        self.name = name
        self.turn = turn
        self.place_x = place_x
        self.place_y = place_y
        self.board_number = board_number
        self.money = money
        self.busnumber = busnumber
        self.compnumber = compnumber
        self.jailcount = jailcount
#piece objects tracks values for each piece

pieces_list = [Piece(0, 'yes', "Blue Monkey", 640, 715, 0, 1500, 0, 0, 0),
               Piece(1, 'no', "Green Monkey", 640, 690, 0, 1500, 0, 0, 0),
               Piece(2, 'no', "Red Monkey", 640, 665, 0, 1500, 0, 0, 0),
               Piece(3, 'no', "Pink Monkey", 640, 640, 0, 1500, 0, 0, 0)]
#list of each piece

class boardplaces:
    def __init__(self, number, cordx, cordy, propertyname, propertytype, subpropertytype, cost, owner, rent0, rent1, rent2, rent3, rent4, rent5, housenumber, colourset, completeset, housecost, house0, mortgaged):
        self.number = number
        self.cordx = cordx
        self.cordy = cordy
        self.property = propertyname
        self.propertytype = propertytype
        self.subpropertytype = subpropertytype
        self.cost = cost
        self.owner = owner
        self.rent0 = rent0
        self.rent1 = rent1
        self.rent2 = rent2
        self.rent3 = rent3
        self.rent4 = rent4
        self.rent5 = rent5
        self.housenumber = housenumber
        self.colourset = colourset
        self.completeset = completeset
        self.housecost = housecost
        self.house0 = house0
        self.mortgaged = mortgaged
#class of board places which number two coordinates, property name, type, and the label image that pops up

board_places_list = [boardplaces(0, 640, 715, 'GO', 'go', 'no', 'no', 'no',  'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(1, 588, 715, 'Caledon', 'property', 'property', 60, 'no', 2, 10, 30, 90, 160, 250, 0, 0, False, 50, False, False),
                   boardplaces(2, 532, 715, 'Baboon Bin', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(3, 480, 715, 'Milton','property', 'property', 60, 'no', 4, 20, 60, 180, 320, 450, 0, 0, False, 50, False, False),
                   boardplaces(4, 416, 715, 'Mentor School Fees 200', 'tax', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(5, 360, 715, 'Wayne Bus', 'property', 'bus', 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 8, False, 'no', False, False),
                   boardplaces(6, 304, 715, 'Angola', 'property', 'property', 100, 'no', 6, 30, 90, 270, 400, 550, 0, 1, False, 50, False, False),
                   boardplaces(7, 248, 715, 'Healthcare Hazard', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(8, 192, 715, 'Somalia', 'property', 'property', 100, 'no', 6, 30, 90, 270, 400, 550, 0, 1, False, 50, False, False),
                   boardplaces(9, 136, 715, 'Chad', 'property', 'property', 120, 'no', 8, 40, 100, 300, 450, 600, 0, 1, False, 50, False, False),
                   boardplaces(10, 5, 715, 'Jail', 'jail', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(11, 5, 590, 'Scarborough', 'property', 'property', 140, 'no', 10, 50, 150, 450, 625, 750, 0, 2, False, 100, False, False),
                   boardplaces(12, 5, 534, 'Pepsi Company', 'property', 'company', 150, 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 9, False, 'no', False, False),
                   boardplaces(13, 5, 478, 'Markham', 'property', 'property', 140, 'no', 10, 50, 150, 450, 625, 750, 0, 2, False, 100, False, False),
                   boardplaces(14, 5, 420, 'Primary Campus', 'property', 'property', 160, 'no', 12, 60, 180, 500, 700, 900, 0, 2, False, 100, False, False),
                   boardplaces(15, 5, 364, 'Jeff Bus', 'property', 'bus', 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 8, False, 'no', False, False),
                   boardplaces(16, 5, 302, 'GCP', 'property', 'property', 180, 'no', 14, 70, 200, 550, 750, 950, 0, 3, False, 100, False, False),
                   boardplaces(17, 5, 246, 'Baboon Bin', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(18, 5, 188, 'Mentor Lobby', 'property', 'property', 180, 'no', 14, 70, 200, 550, 750, 950, 0, 3, False, 100, False, False),
                   boardplaces(19, 5, 132, 'Bhav Barn', 'property', 'property', 200, 'no', 16, 80, 220, 600, 800, 1000, 0, 3, False, 100, False, False),
                   boardplaces(20, 5, 5, 'Lunch Break', 'lunch', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(21, 136, 5, 'Mentor Gym', 'property', 'property', 220, 'no', 18, 90, 250, 700, 875, 1050, 0, 4, False, 150, False, False),
                   boardplaces(22, 192, 5, 'Healthcare hazard', 'chest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(23, 248, 5, 'North Korea', 'property', 'property', 220, 'no', 18, 90, 250, 700, 875, 1050, 0, 4, False, 150, False, False),
                   boardplaces(24, 304, 5 ,'mentor office', 'property', 'property', 240, 'no', 20, 100, 300, 750, 925, 1100, 0, 4, False, 150, False, False),
                   boardplaces(25, 360, 5, 'Smith Bus', 'property', 'bus', 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 8, False, 'no', False, False),
                   boardplaces(26, 416, 5, 'Yehia Pyramid', 'property', 'property', 260, 'no', 22, 110, 330, 800, 975, 1150, 0, 5, False, 150, False, False),
                   boardplaces(27, 472, 5, 'Egypt', 'property', 'property', 260, 'no', 22, 110, 330, 800, 975, 1150, 0, 5, False, 150, False, False),
                   boardplaces(28, 532, 5, 'Coca Cola Company', 'property', 'company', 150, 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 9, False, 'no', False, False),
                   boardplaces(29, 588, 5, 'Land Down Under', 'property', 'property', 280, 'no', 24, 120, 360, 850, 1025, 1200, 0, 5, False, 150, False, False),
                   boardplaces(30, 710, 5, 'Go To Brampton', 'gotojail', 'no', 'no','no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(31, 710, 132, 'Evan Camp', 'property', 'property', 300, 'no', 26, 130, 390, 900, 1100, 1275, 0, 6, False, 200, False, False),
                   boardplaces(32, 710, 188, 'Greenland Park', 'property', 'property', 300, 'no', 26, 130, 390, 900, 1100, 1275, 0, 6, False, 200, False, False),
                   boardplaces(33, 710, 246, 'Baboon Bin', 'chest', 'no', 'no', 'no','no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(34, 710, 302, 'Oakville', 'property', 'property', 320, 'no', 28, 150, 450, 1000, 1200, 1400, 0, 6, False, 200, False, False),
                   boardplaces(35, 710, 364, 'Dan Bus', 'property', 'bus', 200, 'no', 25, 50, 100, 200, 'no', 'no', 0, 8, False, 'no', False, False),
                   boardplaces(36, 710, 422, 'Healthcare hazard', 'chest', 'no', 'no','no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(37, 710, 478, 'Crystal Cove', 'property', 'property', 350, 'no', 35, 175, 500, 1100, 1300, 1500, 0, 7, False, 200, False, False),
                   boardplaces(38, 710, 534, 'field trip 100', 'tax', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 0, 'no', False, 'no', False, False),
                   boardplaces(39, 710, 590, 'jungle of the monkeys', 'property', 'property', 400, 'no', 50, 200, 600, 1400, 1700, 2000, 0, 7, False, 200, False, False)]
#list of all boardplaces and their values

class chest:
    def __init__(self, lbtext, movecom, moneycom):
        self.lbtext = lbtext
        self.movecom = movecom
        self.moneycom = moneycom
#class chest has values for all chest cards

chestlist = [chest('You were late coming in from lunch\n go to the office', 24, -0, ),
             chest('Advance to Smith class to get some cokes', 0, -0),
             chest('Monkey fees, lose 50 cokes', 'no', -50),
             chest('Brayden needs your muck\n lose 25 cokes', 'no', -25),
             chest('You hate yourself\n go to Scarborough', 11, -0),
             chest('You decided you were tired of cokes\n go to the Pepsi company', 12, -0),
             chest('You completed an assignment on time\n receive 50 cokes', 'no', +50),
             chest('Bhavjeet wants you to be his Hartag\n he gave you 200 cokes for it', 'no', +200),
             chest('Smith deemed you king of the monkets\n Receive 100 cokes', 'no', +100),
             chest('Take a trip on Bus Wayne', 5, -0),
             chest('You a ugly ah monkey and won\n second last in a beauty contest\n collect 10 cokes', 'no', +10),
             chest('Some monkey robbed a class\n and dropped the cokes\n collect 150 cokes', 'no', +150),
             chest('You brought your coke into class\n and Mcrae took it\n lose 100 cokes', 'no', -100)]
#list of all cards

gameboard = game(0, -1, 0, 0, False, False, False, False, False, False, False, 0, False, 0, False, 0, False, False, 0, 0, False, False, 0, 0, False, False, False, False, False, False, False, False, False, pieces_list, board_places_list, chestlist, False)
#make the one game object which includes the pieces and board places list