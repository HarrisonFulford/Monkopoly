import socket
from tkinter import *
from PIL import ImageTk, Image
import tkinter as tk
from Labels import *
from boardplaces import *
from pieces import pieceslist
import random
from chest import *

class Network:
    def __init__(self):
        # Create a new socket object for the client
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Store the IP address of the server
        self.server = "172.20.10.4"
        # Store the port number that the server is listening on
        self.port = 5555
        # Create a tuple containing the server IP address and port number
        self.addr = (self.server, self.port)
        # Attempt to connect the client socket to the server and store the response
        self.id = self.connect()
        # Print the response to the console
        print(self.id)

    def connect(self):
        try:
            # Attempt to connect the client socket to the server
            self.client.connect(self.addr)
            # Receive up to 2048 bytes of data from the server and decode it using UTF-8
            return self.client.recv(2048).decode()
        except Exception as e:
            # If an error occurs, print the error message to the console
            print(f"Error connecting to server: {e}")

    def send(self, data):
        try:
            # Encode the string as bytes using UTF-8 and send them to the server
            self.client.send(str.encode(f"Client {self.id}: " + data))
        except socket.error as e:
            # If a socket error occurs, print the error message to the console
            print(e)
    def receive(self):
        try:

            while True:
                # Receive up to 2048 bytes of data from the server and decode it using UTF-8
                data = ''
                data = self.client.recv(2048).decode()
                print(data)
                client_id = data.split(':')[0].strip()
                if len(data.split(':')) > 1:
                    number = data.split(':')[1].strip()
                    print(number)
                        
                if 'client 1' in data:
                    pind = 0
                if 'client 2' in data:
                    pind = 1
                if 'client 3' in data:
                    pind = 2
                if 'client 4' in data:
                    pind = 3
                x = pieceslist[pind]
                x.boardnumber += int(number)
                if x.boardnumber >= 40:
                    x.boardnumber -= 40
                for item in boardplaceslist:
                    if item.number == x.boardnumber:
                        x.label.place(x=item.cordx, y =item.cordy)
                        if pieceslist[pind].boardnumber == 30:
                            print('jail')
                            x.label.place(x=60, y=660)
                            jaillb = Label(gui, text='JAIL!', height =1, width=10, bg='#D5E8D4', fg='green', font=('Cooper Std Black', 30))
                            jaillb.place(x=428, y =132)
                            x.boardnumber = 10
                        if item.propertytype == 'chest':
                            #if that boardplace is a chest type
                            m = random.randint(0,12)
                            #chooses random number for random card
                            def chestbuttondestroy():
                                #executes command when the chest card button is clicked
                                chestbutton.destroy()
                                #destroys the button on screen
                                rollbut['state'] = NORMAL
                                #make the roll state normal which means the next player can roll.
                                x.money += chestlist[m].moneycom
                                #adds money or removes money if money is involved in card
                                x.moneylabel.config(text=pieceslist[pind].money)
                                #changes that piece's money label
                                if chestlist[m].movecom != 'no' and chestlist[m].movecom != '-3':
                                    # if there is movement
                                    if x.boardnumber < chestlist[m].movecom:
                                        x.money += 200
                                        #if the piece is about to make one full rotation around the board and pass go add 200 to money
                                    x.boardnumber = chestlist[m].movecom
                                    #set the place on the board to the card's movement

                            if x.boardnumber == 2 or x.boardnumber == 17 or x.boardnumber == 33:
                                chestbutton = Button(gui, bg = 'brown', highlightbackground='brown', text=chestlist[m].lbtext, height=12, width=30, command=chestbuttondestroy)
                                chestbutton.place(x=300, y=270)
                                rollbut['state'] = DISABLED
                            #if it is a monkey bin makes the card brown

                            if x.boardnumber == 7 or x.boardnumber == 22 or x.boardnumber == 36:
                                chestbutton = Button(gui, bg = 'yellow', highlightbackground='yellow', text=chestlist[m].lbtext, height=12, width=30, command=chestbuttondestroy)
                                chestbutton.place(x=300, y=270)
                                rollbut['state'] = DISABLED
                            #if it is a health care hazard make it yellow
                        if item.propertytype == 'property':
                            def passfunc():
                                propgui.destroy()
                                rollbut['state'] = NORMAL
                            def buyfunc():
                                rollbut['state'] = NORMAL
                                x.money -= item.cost
                                x.moneylabel.config(text=x.money)
                                propgui.destroy()
                                if x.boardnumber > 10 and x.boardnumber < 20:
                                    for line in x.vertcolour:
                                        line.place(x=item.cordx+110, y=item.cordy-16)
                                        x.vertcolour.remove(line)
                                        item.owner = x.piecenumber
                                elif x.boardnumber > 30:
                                    for line in x.vertcolour:
                                        line.place(x=item.cordx-94, y=item.cordy-16)
                                        x.vertcolour.remove(line)
                                        item.owner = x.piecenumber
                                elif x.boardnumber > 20 and x.boardnumber < 30:
                                    for line in x.horcolour:
                                        line.place(x=item.cordx-16, y=item.cordy+106)
                                        x.horcolour.remove(line)
                                        item.owner = x.piecenumber
                                elif x.boardnumber > 0 and x.boardnumber < 10:
                                    for line in x.horcolour:
                                        line.place(x=item.cordx-16, y=item.cordy-106)
                                        x.horcolour.remove(line)
                                        item.owner = x.piecenumber
                            if item.owner == 'no':
                                rollbut['state'] = DISABLED
                                propgui = tk.Toplevel()
                                propgui.geometry('800x608')
                                costlb = Label(propgui, text='$'+str(item.cost), height =1, width=10, font=('Cooper Std Black', 48))
                                costlb.place(x=508, y =1)
                                newlb = tk.Label(propgui, image=item.label)
                                newlb.place(x=1, y=1)
                                buybutton = Button(propgui, text='buy', bg='green', highlightbackground='green',height=10, width=26, command=buyfunc)
                                buybutton.place(x=528, y=74)
                                passbutton = Button(propgui, text='pass', bg='red', highlightbackground='red',height=10, width=26, command=passfunc)
                                passbutton.place(x=528, y=304)
                                propgui.mainloop()
                        if item.number == 4:
                            x.money -= 200
                            x.moneylabel.config(text=x.money)
                        if item.number == 38:
                            x.money -= 100
                            x.moneylabel.config(text=x.money)
                return (client_id, number)
        except socket.error as e:
            # If a socket error occurs, print the error message to the console
            print(e)

n = Network ()

def newmovefunc():
    print(n.send('rolled'))
    rep = n.receive()
    print(rep)
    #print(n.receive())

playerturngui = Tk()
playerturngui.geometry('350x200+300+300')
playerturngui.title('Player Turn')
rollbut = Button(playerturngui, height=5, width=5, text='roll', command=newmovefunc) #roll button
rollbut.place(x = '1', y = '1')
#Make the playerturn tkinter window and add the roll button

#lb.place(x='100', y='1')
def destroyfunc(): #When they click on x of window closes both tkinter windows
    gui.destroy()
    playerturngui.destroy()

gui.resizable(False, False) #Does not allow the window to be resized
playerturngui.resizable(False, False) #Does not allow the window to be resized
def nah(): #does not allow the player turn window to be closed 
    pass
playerturngui.wm_protocol("WM_DELETE_WINDOW", nah) #makes the command nah when they try to close so it does not allow close
gui.wm_protocol("WM_DELETE_WINDOW", destroyfunc) #destroys both windows
playerturngui.mainloop()
gui.mainloop()

#a = True
#while a != False:
    #message = input('rolled')
    #n.send(message)
    

#while True:
    #message = input("Enter message to send: ")
    #n.send(message)
    #print(n.receive())
